//HugeInt.cpp
#include <iostream>
#include <string>
#include <cmath>
#include <cstring>
#include <iomanip>
#include "HugeInt.h"
using namespace std;

int xi;	//for(xi...)
HugeInt::HugeInt(long INT)
{
	setY(INT);
}

HugeInt::HugeInt(char *STRING)
{
	setZ(STRING);
}

void HugeInt::setY(long INT)
{
//save the huge integer into array
	for (xi = 0; xi < 50; ++xi) {
		double power1 = pow(10, (double)xi+1);
		double power2 = pow(10, (double)xi);
		value[50-xi-1] = (INT%(int)power1-INT%(int)power2)/power2;
	}
}

void HugeInt::setZ(char *STRING)
{
	for (xi = 0; xi < 50; ++xi) {
		value[xi] = 0;
	}
	int size = strlen(STRING);
	int xj = 0;
	for (xi = 50-size; xi < 50; ++xi, ++xj) {
		value[xi] = STRING[xj]-'0';
	}
}

HugeInt HugeInt::operator+(const HugeInt &plus) const
{
	HugeInt temp;
	int carry = 0;
	for (xi = 49; xi >= 0; --xi) {
		temp.value[xi] = value[xi] + plus.value[xi] + carry;
		if (temp.value[xi] > 9) {
			temp.value[xi]-=10;
			carry = 1;
		}
		else carry = 0;
	}
	return temp;
}

HugeInt HugeInt::operator-(const HugeInt &minus) const
{
	HugeInt temp;
	int carry = 0;
	for (xi = 49; xi >= 0; --xi) {
		temp.value[xi] = value[xi] - minus.value[xi] - carry;
		if (temp.value[xi] < 0) {
			temp.value[xi]+=10;
			carry = 1;
		}
		else carry = 0;
	}
	return temp;
}
/*
HugeInt HugeInt::operator*(const HugeInt &mul) const
{
	HugeInt temp;
	int carry = 0;
	for (xi = 49; xi >= 0; --xi) {
		temp.value[xi] = value[xi] * mul.value[xi] + carry;
		if (temp.value[xi] > 9) {
			carry = (temp.value[xi]-(temp.value[xi]%10))/10;
			temp.value[xi]%=10;
		}
		else carry = 0;
	}
	return temp;
}
*/
bool HugeInt::operator==(const HugeInt &boolean) const
{
	for (xi = 0; xi < 50; ++xi) {
		if (value[xi] != boolean.value[xi]) return false;
	}
	return true;
}

bool HugeInt::operator>=(const HugeInt &boolean) const
{
	for (xi = 0; xi < 50; ++xi) {
		if (value[xi] > boolean.value[xi]) return true;
		else if (value[xi] < boolean.value[xi]) return false;
	}
	return true;
}

bool HugeInt::operator<=(const HugeInt &boolean) const
{
	for (xi = 0; xi < 50; ++xi) {
		if (value[xi] < boolean.value[xi]) return true;
		else if (value[xi] > boolean.value[xi]) return false;
	}
	return true;
}

bool HugeInt::operator!=(const HugeInt &boolean) const
{
	for (xi = 0; xi < 50; ++xi) {
		if (value[xi] != boolean.value[xi]) return true;
	}
	return false;
}

istream &operator>>(istream &input, HugeInt &num)
{
	char temp[50] = "0";
	input >> temp;
	int size = 50;
	for (xi = 0; xi < 50; ++xi) {
		if (temp[xi] == 0) size--;
	}
	int xj = 0;
	for (xi = 50-size; xi < 50; ++xi, ++xj) {
		num.value[xi] = temp[xj]-'0';
	}
	return input;
}

ostream &operator<<(ostream &output, const HugeInt &num)
{
	int size = 50;
	for (xi = 0; xi < 50; ++xi) {
		if (num.value[xi] == 0) size--;
	}
	for (xi = 50-size; xi < 50; ++xi) {
		output << num.value[xi];
	}
	return output;
}
