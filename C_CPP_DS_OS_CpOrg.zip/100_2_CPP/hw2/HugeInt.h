//HugeInt.h
#ifndef HUGEINT_H
#define HUGEINT_H

#include <string>
using namespace std;

class HugeInt
{
	friend istream &operator>>(istream &, HugeInt &);
	friend ostream &operator<<(ostream &, const HugeInt &);
public:
	HugeInt(long = 0);
	HugeInt(char *);
	void setY(long);
	void setZ(char *);
	HugeInt operator+(const HugeInt &) const;
	HugeInt operator-(const HugeInt &) const;
	//HugeInt operator*(const HugeInt &) const;
	bool operator==(const HugeInt &) const;
	bool operator>=(const HugeInt &) const;
	bool operator<=(const HugeInt &) const;
	bool operator!=(const HugeInt &) const;

private:
	int value[50];
};

#endif
