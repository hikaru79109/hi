#include <iostream>
#include <string>
#include "HugeInt.h"

int main()
{
	HugeInt x;
	HugeInt y(28825252);
	HugeInt z("314159265358979323846");
	HugeInt result;
	cin >> x;
	result = x+y;
	cout << x << "+" << y << " = " << result << endl;
	result = z-x;
	cout << z << "-" << x << " = " << result << endl;
	//result = x*y;
	//cout << x << "*" << y << " = " << result << endl;
	if (x == y) cout << "Equal" << endl;
	else cout << "Not Equal" << endl;
	if (x >= y) cout << "Greater or Equal" << endl;
	else cout << "Less" << endl;
	if (x <= y) cout << "Less Than or Equal" << endl;
	else cout << "Greater" << endl;
	if (x != y) cout << "Not Equal" << endl;
	else cout << "Equal" << endl;
	return 0;
}
