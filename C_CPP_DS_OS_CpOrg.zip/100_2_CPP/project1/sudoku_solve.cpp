//sudoku_solve.cpp
#include <ncurses/curses.h>
#include <unistd.h> // for sleep( )
#include "sudoku_solve.h"
#define fail 59
#define success 100
using namespace std;
int sudoku_solve::inspect_num(sudoku_question &q, int y, int x, int inspection)	//inspect if there is number already on it
{
	if (inspection == 0 && q.loc[y][x] == 0) {
		printw(" "); refresh(); q.loc2[y][x] = 0;
	}
	else {if (q.loc[y][x] == 0) {printw("%d", inspection); refresh(); q.loc2[y][x] = inspection;}}
}

int sudoku_solve::inspect_answer(sudoku_question &q)
{
	int xi, xj, xii, xjj, xr, xk, xc, xnum, xcount = 0;
	//inspect row and column
	for (xi = 0; xi < 9; xi++) {
		for (xj = 0; xj < 9; xj++) {
			for (xnum = 1; xnum < 10; xnum++) {
				if (q.loc2[xi][xj] == xnum) {xcount++; break;}
			}
		}
		if (xcount != 9) return fail;
		xcount = 0;
	}
	//inspect the square
	for (xi = 0; xi < 9; xi++) {
		for (xj = 0; xj < 9; xj++) {
			if (xi%3 == 0 && xj%3 == 0) {
				xr = xi+3;
				xk = xj+3;
				for (xii = xr-3; xii < xr; xii++) {
					for (xjj = xk-3; xjj < xk; xjj++) {
						for (xnum = 1; xnum < 10; xnum++) {
							if (q.loc2[xii][xjj] == xnum) {xcount++; break;}
						}
					}
				}
				if (xcount != 9) return fail;
				xcount = 0;
			}
		}
	}
	return success;
}
