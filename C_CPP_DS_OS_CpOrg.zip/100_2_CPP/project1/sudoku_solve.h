//sudoku_solve.h
#ifndef sudoku_solve_h
#define sudoku_solve_h
#include "sudoku_question.h"
using namespace std;
class sudoku_solve
{
public:
	int inspect_num(sudoku_question &, int, int, int);	//inspect if there is number already on it
	int inspect_answer(sudoku_question &);
};
#endif
