//sudoku_question.cpp
#include <cstdlib>	//for rand()
#include <ncurses/curses.h>
#include <ctime> // for time_t and time( )
#include <unistd.h> // for sleep( )
#include <fstream>
#include "sudoku_question.h"
using namespace std;
sudoku_question::sudoku_question(int *a)
{
	sudoku_question::setLocat(a);
	//generate the question by giving the location number
}

void sudoku_question::setLocat(int *a)
{
	loc[0][0]=loc[1][4]=loc[2][8]=loc[3][3]=loc[4][7]=loc[5][2]=loc[6][6]=loc[7][1]=loc[8][5]=a[0];
	loc[0][1]=loc[1][5]=loc[2][6]=loc[3][4]=loc[4][8]=loc[5][0]=loc[6][7]=loc[7][2]=loc[8][3]=a[1];
	loc[0][2]=loc[1][3]=loc[2][7]=loc[3][5]=loc[4][6]=loc[5][1]=loc[6][8]=loc[7][0]=loc[8][4]=a[2];
	loc[0][3]=loc[1][7]=loc[2][2]=loc[3][6]=loc[4][1]=loc[5][5]=loc[6][0]=loc[7][4]=loc[8][8]=a[3];
	loc[0][4]=loc[1][8]=loc[2][0]=loc[3][7]=loc[4][2]=loc[5][3]=loc[6][1]=loc[7][5]=loc[8][6]=a[4];
	loc[0][5]=loc[1][6]=loc[2][1]=loc[3][8]=loc[4][0]=loc[5][4]=loc[6][2]=loc[7][3]=loc[8][7]=a[5];
	loc[0][6]=loc[1][1]=loc[2][5]=loc[3][0]=loc[4][4]=loc[5][8]=loc[6][3]=loc[7][7]=loc[8][2]=a[6];
	loc[0][7]=loc[1][2]=loc[2][3]=loc[3][1]=loc[4][5]=loc[5][6]=loc[6][4]=loc[7][8]=loc[8][0]=a[7];
	loc[0][8]=loc[1][0]=loc[2][4]=loc[3][2]=loc[4][3]=loc[5][7]=loc[6][5]=loc[7][6]=loc[8][1]=a[8];
}

void sudoku_question::generate_question(int level_in)
{
	//open a file to save the question
	ofstream outputQuestion("Sudoku.txt");
	if (!outputQuestion) {
		exit(1);
	}	//end if
   	int ix, jx, level = 0, nx = 0;
	for (ix = 0; ix < 9; ix++) {
		for (jx = 0; jx < 9; jx++) {
			rand_space[nx] = loc[ix][jx];
			nx++;
		}
	}
	for(; level < level_in;) {
		level = 0;
		for(nx = 0; nx < 81; nx++) {
			if(rand_space[nx] == 0) {level++;}
		}
          	jx = rand()%81;
          	rand_space[jx] = 0;
	}
	nx = 0;
	for (ix = 0; ix < 9; ix++) {
		for (jx = 0; jx < 9; jx++) {
			loc[ix][jx] = rand_space[nx];
			nx++;
			loc2[ix][jx] = loc[ix][jx];
			outputQuestion << loc[ix][jx];
		}
		outputQuestion << endl;
	}
}

void sudoku_question::print_question(int turn)
{
	int ix, jx;
	printw("  － － － － － － － － －\n ");
	for (ix = 0; ix < 9; ix++) {
		for (jx = 0; jx < 9; jx++) {
			if(loc[ix][jx] != 0) {
				printw("｜");
				if (turn == 1) {
					printw("%d", loc2[ix][jx]);
					//print the message	
//					mvaddstr(1, 35, "1~9:enter the number 1~9	");
//					mvaddstr(2, 35, "0:delete the number");
//					mvaddstr(3, 35, "q:quit");
//					refresh(); // print it on to the real screen
				}
				else if(turn == 0) {printw("%d", loc[ix][jx]);}
			}
			else printw("｜ "); 
		}
		printw("｜\n");
		printw("  － － － － － － － － －\n ");
	}
}

void sudoku_question::turn()
{
	int xi, xj;
	for (xi = 0; xi < 9; xi++) {
		for (xj = 0; xj < 9; xj++) {
			loc_turn[xi][xj] = loc[xj][8-xi];
			loc2_turn[xi][xj] = loc2[xj][8-xi];
		}
	}
	for (xi = 0; xi < 9; xi++) {
		for (xj = 0; xj < 9; xj++) {
			loc[xi][xj] = loc_turn[xi][xj];
			loc2[xi][xj] = loc2_turn[xi][xj];
		}
	}
}

void sudoku_question::save() 
{
	int xi, xj;
	//open a file to save the question
	ofstream Save("saving.txt");
	for (xi = 0; xi < 9; xi++) {
		for (xj = 0; xj < 9; xj++) {
			Save << loc2[xi][xj];
			Save << "\n";
		}
	}
}
