//#include <iostream>
#include <cstdlib>	//rand
#include <ncurses/curses.h>
#include <ctime> // for time_t and time( )
#include <unistd.h> // for sleep( )
#include <fstream>
#define ENTER 10
#define fail 59
#define success 100
using namespace std;

class sudoku_question
{
	friend class sudoku_solve;
public:
	sudoku_question(int *a)
	{
		setLocat(a);
		//generate the question by giving the location number
	}

	void setLocat(int *a)
	{
		loc[0][0]=loc[1][4]=loc[2][8]=loc[3][3]=loc[4][7]=loc[5][2]=loc[6][6]=loc[7][1]=loc[8][5]=a[0];
		loc[0][1]=loc[1][5]=loc[2][6]=loc[3][4]=loc[4][8]=loc[5][0]=loc[6][7]=loc[7][2]=loc[8][3]=a[1];
		loc[0][2]=loc[1][3]=loc[2][7]=loc[3][5]=loc[4][6]=loc[5][1]=loc[6][8]=loc[7][0]=loc[8][4]=a[2];
		loc[0][3]=loc[1][7]=loc[2][2]=loc[3][6]=loc[4][1]=loc[5][5]=loc[6][0]=loc[7][4]=loc[8][8]=a[3];
		loc[0][4]=loc[1][8]=loc[2][0]=loc[3][7]=loc[4][2]=loc[5][3]=loc[6][1]=loc[7][5]=loc[8][6]=a[4];
		loc[0][5]=loc[1][6]=loc[2][1]=loc[3][8]=loc[4][0]=loc[5][4]=loc[6][2]=loc[7][3]=loc[8][7]=a[5];
		loc[0][6]=loc[1][1]=loc[2][5]=loc[3][0]=loc[4][4]=loc[5][8]=loc[6][3]=loc[7][7]=loc[8][2]=a[6];
		loc[0][7]=loc[1][2]=loc[2][3]=loc[3][1]=loc[4][5]=loc[5][6]=loc[6][4]=loc[7][8]=loc[8][0]=a[7];
		loc[0][8]=loc[1][0]=loc[2][4]=loc[3][2]=loc[4][3]=loc[5][7]=loc[6][5]=loc[7][6]=loc[8][1]=a[8];
	}
    void generate_question(int level_in)
    {
		//open a file to save the question
		ofstream outputQuestion("Sudoku.txt");
		if (!outputQuestion) {
			exit(1);
		}	//end if
    	int ix, jx, level = 0, nx = 0;
		for (ix = 0; ix < 9; ix++) {
			for (jx = 0; jx < 9; jx++) {
				rand_space[nx] = loc[ix][jx];
				nx++;
			}
		}
		for(; level < level_in;) {
			level = 0;
			for(nx = 0; nx < 81; nx++) {
				if(rand_space[nx] == 0) {level++;}
			}
           	jx = rand()%81;
           	rand_space[jx] = 0;
		}
		nx = 0;
		for (ix = 0; ix < 9; ix++) {
			for (jx = 0; jx < 9; jx++) {
				loc[ix][jx] = rand_space[nx];
				nx++;
				loc2[ix][jx] = loc[ix][jx];
				outputQuestion << loc[ix][jx];
			}
			outputQuestion << endl;
		}
	}
	void print_question()
	{
		int ix, jx;
		printw("  － － － － － － － － －\n ");
		for (ix = 0; ix < 9; ix++) {
			for (jx = 0; jx < 9; jx++) {
				if(loc[ix][jx] != 0) {
					printw("｜");
					printw("%d", loc[ix][jx]);
				}
				else printw("｜ "); 
			}
			printw("｜\n");
			printw("  － － － － － － － － －\n ");
		}
	}
private:
	int loc[9][9];	//unvariable(之後用來判斷該位置是否有題目)
	int loc2[9][9];	//variable(to save what you enter)
	int rand_space[81];	//產生空格的位置
};	//end class sudoku_question

class sudoku_solve
{
public:
	int inspect_num(sudoku_question &q, int y, int x, int inspection)	//inspect if there is number already on it
	{
		if (inspection == 0 && q.loc[y][x] == 0) {
			printw(" "); refresh(); q.loc2[y][x] = 0;
		}
		else {if (q.loc[y][x] == 0) {printw("%d", inspection); refresh(); q.loc2[y][x] = inspection;}}
	}

	int inspect_answer(sudoku_question &q)
	{
		int xi, xj, xii, xjj, xr, xk, xc, xnum, xcount = 0;
		//inspect row and column
		for (xi = 0; xi < 9; xi++) {
			for (xj = 0; xj < 9; xj++) {
				for (xnum = 1; xnum < 10; xnum++) {
					if (q.loc2[xi][xj] == xnum) {xcount++; break;}
				}
			}
			if (xcount != 9) return fail;
			xcount = 0;
		}
		//inspect the square
		for (xi = 0; xi < 9; xi++) {
			for (xj = 0; xj < 9; xj++) {
				if (xi%3 == 0 && xj%3 == 0) {
					xr = xi+3;
					xk = xj+3;
					for (xii = xr-3; xii < xr; xii++) {
						for (xjj = xk-3; xjj < xk; xjj++) {
							for (xnum = 1; xnum < 10; xnum++) {
								if (q.loc2[xii][xjj] == xnum) {xcount++; break;}
							}
						}
					}
					if (xcount != 9) return fail;
					xcount = 0;
				}
			}
		}
		return success;
	}
};

int main()
{
	int width, height, level, level_in;
	int c, x = 0, y = 1;
	int go_on, restart;
	//ncurses start
	setlocale(LC_ALL,"");
	initscr();
	cbreak(); // disable key buffering
	noecho(); // disable echoing
	keypad(stdscr, TRUE); // enable keypad reading
	getmaxyx(stdscr, height, width); // get screen size
	int ax[9] = {0};
	sudoku_question s1(ax);
	sudoku_solve s2;
	
//---------------------------------------------------------------
	//generate the question
	int r, k, xj, rand_num[9];
	restart = TRUE;
	while (restart) {
		int yy = 5, xx = 15;
		go_on = TRUE;
		mvaddstr(0, 0, "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");	//to cover 
		while (go_on) {
			mvaddstr(5, 15, "Easy");
			mvaddstr(7, 15, "Medium");
			mvaddstr(9, 15, "Hard");
			move(yy,xx);
			level = getch();
			switch (level) {
				case KEY_UP: yy -= 2; break;
				case KEY_DOWN: yy += 2; break;
				case ENTER: level = yy; go_on = FALSE; break;
				default: break;
			}
			if (yy < 5) yy = 9;
			else if (yy > 9) yy = 5;
		}	//end while (go_on)
		if (level == 5) level_in = 30;
		else if (level == 7) level_in = 35;
		else if (level == 9) level_in = 40;
		move(0,0);
		go_on = TRUE;
		while (go_on) {		//whether generate a new question
			srand(time(NULL));
    		for (r = 0; r < 9; r++) {
    		    rand_num[r] = (rand()%9)+1;
    		    for (k = 0; k < r; k++) {
    		        if (rand_num[r] == rand_num[k]) {
    		            r--;
						break;
    		        }
    		    }
			}	//1~9亂排
			xj = rand()%81;
			sudoku_question s3(rand_num);
			s3.generate_question(level_in);
			s3.print_question();
			s1 = s3;
			refresh();
			mvaddstr(1, 35, "n:to generate a new question");
			mvaddstr(2, 35, "press enter to start");
			move(0, 0);
			while (go_on) {
				c = getch();
				if (c == 'n') break;
				else if (c == ENTER) go_on = FALSE;
			}	//end while (go_on)
		}	//end while (go_on)

		//time-start
		time_t t1, t2;
		t1 = time(NULL); // get elapsed seconds since 1970/1/1 00:00:00
	
		//print the message	
		mvaddstr(1, 35, "1~9:enter the number 1~9	");
		mvaddstr(2, 35, "0:delete the number");
		mvaddstr(3, 35, "q:quit");
		refresh(); // print it on to the real screen
	
		//beneath is ncurses(moving or enter number)
		int inspection;		//to save the number for what you enter
		int kx = -1, ky = 0;
		go_on = TRUE;
		time(&t2);
		int t, result;	//t:gap of time; result:whether the answer is correct
		while (go_on) {
			nodelay(stdscr, TRUE);
			c = getch();
			time(&t2);
			t = t2-t1;
			move(4, 35);
			printw("time: %d sec", t);
			refresh();
			move(y, x);
			attron(A_REVERSE);
			switch (c) {
				case KEY_LEFT: x = x-3; kx = kx-1; break;
				case KEY_RIGHT: x = x+3; kx = kx+1; break;
				case KEY_UP: y = y-2; ky = ky-1; break;
				case KEY_DOWN: y = y+2; ky = ky+1; break;
				case '1': inspection = 1; s2.inspect_num(s1, ky, kx, inspection); break;
				case '2': inspection = 2; s2.inspect_num(s1, ky, kx, inspection); break;
				case '3': inspection = 3; s2.inspect_num(s1, ky, kx, inspection); break;
				case '4': inspection = 4; s2.inspect_num(s1, ky, kx, inspection); break;
				case '5': inspection = 5; s2.inspect_num(s1, ky, kx, inspection); break;
				case '6': inspection = 6; s2.inspect_num(s1, ky, kx, inspection); break;
				case '7': inspection = 7; s2.inspect_num(s1, ky, kx, inspection); break;
				case '8': inspection = 8; s2.inspect_num(s1, ky, kx, inspection); break;
				case '9': inspection = 9; s2.inspect_num(s1, ky, kx, inspection); break;
				case '0': inspection = 0; s2.inspect_num(s1, ky, kx, inspection); break;  //delete the number
				case 'q': go_on = FALSE; break;	//quit the game
				case ENTER: result = s2.inspect_answer(s1); if(result == success) {move(6, 35); printw("correct!!"); go_on = FALSE;} break;
				default: break;	//do nothing
			} //end switch (c)
			attroff(A_REVERSE);
			while (x < 0) x += width;
			while (x >= width) x -= width;
			while (y < 0) y += height;
			while (y >= height) y -= height;
		} //end while (go_on)
			mvaddstr(7, 35, "Enter: Exit!");
			mvaddstr(8, 35, "r: Play again!");
			refresh();
			go_on = TRUE;
			while (go_on) {
				c = getch();
				switch (c) {
					case 'r': go_on = FALSE; break;
					case ENTER: go_on = FALSE; restart = FALSE; break;
					default: break;
				}
			}
	}	//end while (restart)
	endwin();
}	//end main()
