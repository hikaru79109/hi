//main.cpp
#include <cstdlib>	//rand
#include <ncurses/curses.h>
#include <ctime> // for time_t and time( )
#include <unistd.h> // for sleep( )
#include <fstream>
#include "sudoku_question.h"
#include "sudoku_solve.h"
#define ENTER 10
#define fail 59
#define success 100
using namespace std;
int main()
{
	int width, height, level, level_in;
	int c, x = 0, y = 1;
	int go_on, restart;
	//ncurses start
	setlocale(LC_ALL,"");
	initscr();
	cbreak(); // disable key buffering
	noecho(); // disable echoing
	keypad(stdscr, TRUE); // enable keypad reading
	getmaxyx(stdscr, height, width); // get screen size
	int ax[9] = {0};
	sudoku_question s1(ax);
	sudoku_solve s2;
	
//---------------------------------------------------------------
	//generate the question
	int r, k, xj, rand_num[9];
	restart = TRUE;
	while (restart) {
		int yy = 5, xx = 15;
		go_on = TRUE;
		mvaddstr(7, 35, "				");	//to cover the string "Enter: to exit!"
		mvaddstr(8, 35, "				");	//to cover the string "r: Play again!"
		while (go_on) {
			mvaddstr(5, 15, "Easy");
			mvaddstr(7, 15, "Medium");
			mvaddstr(9, 15, "Hard");
			mvaddstr(11, 15, "quit");
			move(yy,xx);
			level = getch();
			switch (level) {
				case KEY_UP: yy -= 2; break;
				case KEY_DOWN: yy += 2; break;
				case ENTER: level = yy; go_on = FALSE; break;
				default: break;
			}
			if (yy < 5) yy = 11;
			else if (yy > 11) yy = 5;
		}	//end while (go_on)
		if (level == 5) level_in = 30;
		else if (level == 7) level_in = 35;
		else if (level == 9) level_in = 40;
		else if (level == 11) exit(1);
		move(0,0);
		go_on = TRUE;
		while (go_on) {		//whether generate a new question
			srand(time(NULL));
    		for (r = 0; r < 9; r++) {
    		    rand_num[r] = (rand()%9)+1;
    		    for (k = 0; k < r; k++) {
    		        if (rand_num[r] == rand_num[k]) {
    		            r--;
						break;
    		        }
    		    }
			}	//1~9亂排
			xj = rand()%81;
			sudoku_question s3(rand_num);
			s3.generate_question(level_in);
			s3.print_question();
			s1 = s3;
			refresh();
			mvaddstr(1, 35, "n:to generate a new question");
			mvaddstr(2, 35, "press enter to start");
			move(0, 0);
			while (go_on) {
				c = getch();
				if (c == 'n') break;
				else if (c == ENTER) go_on = FALSE;
			}	//end while (go_on)
		}	//end while (go_on)

		//time-start
		time_t t1, t2;
		t1 = time(NULL); // get elapsed seconds since 1970/1/1 00:00:00
	
		//print the message	
		mvaddstr(1, 35, "1~9:enter the number 1~9	");
		mvaddstr(2, 35, "0:delete the number");
		mvaddstr(3, 35, "q:quit");
		refresh(); // print it on to the real screen
	
		//beneath is ncurses(moving or enter number)
		int inspection;		//to save the number for what you enter
		int kx = -1, ky = 0;
		go_on = TRUE;
		time(&t2);
		int t, result;	//t:gap of time; result:whether the answer is correct
		while (go_on) {
			nodelay(stdscr, TRUE);
			c = getch();
			time(&t2);
			t = t2-t1;
			move(4, 35);
			printw("time: %d sec", t);
			refresh();
			move(y, x);
			attron(A_REVERSE);
			switch (c) {
				case KEY_LEFT: x = x-3; kx = kx-1; break;
				case KEY_RIGHT: x = x+3; kx = kx+1; break;
				case KEY_UP: y = y-2; ky = ky-1; break;
				case KEY_DOWN: y = y+2; ky = ky+1; break;
				case '1': inspection = 1; s2.inspect_num(s1, ky, kx, inspection); break;
				case '2': inspection = 2; s2.inspect_num(s1, ky, kx, inspection); break;
				case '3': inspection = 3; s2.inspect_num(s1, ky, kx, inspection); break;
				case '4': inspection = 4; s2.inspect_num(s1, ky, kx, inspection); break;
				case '5': inspection = 5; s2.inspect_num(s1, ky, kx, inspection); break;
				case '6': inspection = 6; s2.inspect_num(s1, ky, kx, inspection); break;
				case '7': inspection = 7; s2.inspect_num(s1, ky, kx, inspection); break;
				case '8': inspection = 8; s2.inspect_num(s1, ky, kx, inspection); break;
				case '9': inspection = 9; s2.inspect_num(s1, ky, kx, inspection); break;
				case '0': inspection = 0; s2.inspect_num(s1, ky, kx, inspection); break;  //delete the number
				case 'q': go_on = FALSE; break;	//quit the game
				case ENTER: result = s2.inspect_answer(s1); if(result == success) {move(6, 35); printw("correct!!"); go_on = FALSE;} break;
				default: break;	//do nothing
			} //end switch (c)
			attroff(A_REVERSE);
			while (x < 0) x += width;
			while (x >= width) x -= width;
			while (y < 0) y += height;
			while (y >= height) y -= height;
		} //end while (go_on)
			mvaddstr(7, 35, "Enter: Exit!");
			mvaddstr(8, 35, "r: Play again!");
			refresh();
			go_on = TRUE;
			while (go_on) {
				c = getch();
				switch (c) {
					case 'r': go_on = FALSE; break;
					case ENTER: go_on = FALSE; restart = FALSE; break;
					default: break;
				}
			}
	}	//end while (restart)
	endwin();
}	//end main()
