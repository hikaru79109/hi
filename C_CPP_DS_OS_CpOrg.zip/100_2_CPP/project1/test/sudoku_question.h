//sudoku_question.h
#ifndef SUDOKU_QUESTION_H
#define SUDOKU_QUESTION_H
using namespace std;
class sudoku_question
{
	friend class sudoku_solve;
public:
	sudoku_question(int*);
	void setLocat(int*);
    void generate_question(int);
	void print_question();
private:
	int loc[9][9];	//unvariable(之後用來判斷該位置是否有題目)
	int loc2[9][9];	//variable(to save what you enter)
	int rand_space[81];	//產生空格的位置
};
#endif
