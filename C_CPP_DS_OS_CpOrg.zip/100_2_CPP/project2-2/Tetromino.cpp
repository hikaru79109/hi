//Tetromino.cpp
#include <iostream>
#include <ncurses/curses.h>
#include "Tetromino.h"
using namespace std;

static int grade = 0;
Tetromino::Tetromino(int w, int h)
{
	int i, j;
	static int k = 0;
	width = w;
	height = h;
	while (k == 0) { // 只要建立一次陣列就好
		setdata();
		++k;
	}
}

int Tetromino::getGrade() // 傳分數給main
{
	return grade;
}

void Tetromino::setdata() // 建立二維陣列
{
	drop_data = new int*[height];
	for (int i = 0; i < height; ++i) {
		drop_data[i] = new int[10];
	}

	save_data = new int*[height];
	for (int i = 0; i < height; ++i) {
		save_data[i] = new int[10];
	}
}

void Tetromino::draw()
{
	attrset(COLOR_PAIR(3));
	int go_on = true, y = 0, x = 29;
	while (go_on) {
		mvaddstr(y, x, "|");
		y++;
		if (y > height && x == 29) {
			for (x = 30, y = height; x < 70; ++x) {
				mvaddstr(y-1, x, "_");
			}
			x = 70; 
			y = 0;
		}
		else if (y > height && x == 70) go_on = false;
	}
	attrset(A_NORMAL);
}

void Tetromino::deleCube() // 將前一次印的方塊蓋掉
{
	int i, j;
	attrset(A_NORMAL);
	for (i = 0; i < 4; ++i) {  // 把上一次印的方塊蓋過去
		for (j = 0; j < 4; ++j) {
			if (lastcube[i][j] == 1) {
				move(lasty+2*i, lastx+4*j);	// move->ncurses的
				printw("    ");
				move(lasty+2*i+1, lastx+4*j);
				printw("    ");
			}
		}
	}
}

void Tetromino::printCube(int y, int x, int k) // 將方塊印出
{
	int i, j;
	switch(k) {
		case 0: attrset(COLOR_PAIR(1)); break;
		case 1:	attrset(COLOR_PAIR(2)); break;
		case 2:	attrset(COLOR_PAIR(3)); break;
		case 3:	attrset(COLOR_PAIR(4)); break;
		case 4:	attrset(COLOR_PAIR(5)); break;
		case 5:	attrset(COLOR_PAIR(6)); break;
		case 6:	attrset(COLOR_PAIR(7)); break;
	}
		
	for (i = 0; i < 4; ++i) {
		for (j = 0; j < 4; ++j) {
			lastcube[i][j] = cube[i][j];  //將這次的方塊位置紀錄
			if (cube[i][j] == 1) { 	      //用來在下次print方塊前，把先前的方塊蓋過去
				move(y+2*i, x+4*j);
				printw("    ");  	 //印四個空格，每一個方塊寬四格，高兩格
				move(y+2*i+1, x+4*j);//所以印兩次
				printw("    ");
			}
		}
	}
	lastx = x;
	lasty = y;
	attrset(A_NORMAL);
}

int Tetromino::expectX(int x) // 檢查左右邊界
{
	int i, j;
	if (x < 22) x = 22;
	else if (x > 62) x = 62;
	else if (x > 54) {
		int j = 3;
		while (j > 1) {
			for (int i = 0; i < 4; ++i) {
				if (cube[i][j] == 1) {	//當第j行出現1(第j行有方塊)
					if (j == 3 && x == 58) x -= 4;  //if j==3:最右邊那一行有方塊
					else if (j == 2 && x == 62) x -= 4;		  //if j==2:第二行有方塊
					j = 0;  //結束檢查
					break;
				}
			}
			--j;
		}
	}
	else if (x < 30) {
		int j = 0;
		while (j < 2) {
			for (int i = 0; i < 4; ++i) {
				if (cube[i][j] == 1) {
					if (j == 0 && x == 26) x += 4;  //if j==0:第一行有方塊
					else if (j == 1 && x == 22) x += 4;		  //if j==1:第二行有方塊
					j = 4;  //結束檢查
					break;
				}
			}
			++j;
		}
	}

	return x;
}

double Tetromino::expectY(double y, int &temp) // 檢查底下邊界
{
	int i, j;
	//			printw("##%lf##",y);
	if (y > height-5) {
		y = height-5;
		++temp;
	}
	if (y > height-9) {
		int i = 3;
		while (i > 1) {
			for (int j = 0; j < 4; ++j) {
				if (cube[i][j] == 1) {
					printw("!!%lf!!", y);
					if (i == 3 && y >= height-5) {y = y - 4; ++temp;printw("@1@");} // i=3最後一列(第四列)
					else if (i == 3 && y >= height-6) {y = y - 3; ++temp;printw("@2@");}
					else if (i == 3 && y >= height-7) {y = y - 2; ++temp;printw("@3@");}
					else if (i == 3 && y >= height-8) {y = y - 1; ++temp;printw("@4@");}
					else if (i == 2 && y == height-5) {y = y - 2; ++temp;} // i=2第三列
					else if (i == 2 && y >= height-6) {y = y - 1; ++temp;}
					i = 0;
					printw("%lf",y);
					break;
				}
			}
			--i;
		}
	}

	return y;
}

void Tetromino::deleData(int y, int x) // 消除上一次的位置
{
	for (int i = 0; i < height; ++i) {
		for (int j = 0; j < 10; ++j) {
			drop_data[i][j] = 0;
		}
	}
}
	
void Tetromino::dropData(int y, int x) // 記錄目前掉落的位置
{
	int i, j;
	Tetromino::deleData(y, x);
	int tempx = (x-30)/4; // 轉換成10塊(4格為一塊)
	for (j = 0; j < 4; ++j) {
		for (i = 0; i < 4; ++i) {
			if (cube[i][j] == 1) {
				drop_data[y+2*i][tempx+j] = 1;
				drop_data[y+2*i+1][tempx+j] = 1;
			}
		}
	}
}

void Tetromino::saveData(int y, int x) // 把資料記錄
{
	int i, j;
	for (i = 0; i < height; ++i) {
		for (j = 0; j < 10; ++j) {
			if (save_data[i][j] == 1 || drop_data[i][j] == 1) save_data[i][j] = 1;
		}
	}
}

int Tetromino::expect(int dir, int &x, double &y) // 檢查會不會碰到下面的方塊，和左右移動旁邊有沒有方塊
{
	int i, j;
	if (dir == 3) {
		for (i = height-1; i >= 0; --i) {
			for (j = 9; j >= 0; --j) {
				if (save_data[i][j] == 1 && drop_data[i][j] == 1) {
					--y;
					dropData(y, x);
					j = 9;
				}
			}
		}
	}
					
	for (i = 0; i < height-1; ++i) {
		for (j = 9; j >= 0; --j) {
			if (dir == 1 && save_data[i][j+1] == 1 && drop_data[i][j] == 1) {
				x-=4;
				dropData(y, x);
				i = height;
				break;
			}
			else if (dir == 2 && save_data[i][j-1] == 1 && drop_data[i][j] == 1) {
				x+=4;
				dropData(y, x);
				i = height;
				break;
			}
			else if (save_data[i+1][j] == 1 && drop_data[i][j] == 1) return 0;
		}
	}
				
	return 1;
}

void Tetromino::deleline(int de_line) // 執行消行並整理畫面
{
	int i, j, k = 0, m = 0, d=0;
	++grade;
	for (i = de_line; i > 0; --i) {
		for (j = 0; j < 10; ++j) {
			save_data[i][j] = save_data[i-1][j];
		}
	}
	for (i = height-2; i >= 0; i-=2) {
		for (j = 9; j >= 0; --j) {
			if (save_data[i][j] == 0) {
				move(i, 30+4*j);
				printw("    ");
				move(i-1, 30+4*j);
				printw("    ");
			}
		}
	}
}

void Tetromino::delePossibleLine() // 判斷可不可以消行
{
	for (int i = 0; i < height-1; ++i) {
		int j = 0;
		while (j < 10) {
			if (save_data[i][j] == 1) j++;
			else break;
		}
		if (j == 10) deleline(i);
	}
}
