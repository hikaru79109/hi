//Tetromino.h
#ifndef TETROMINO_H
#define TETROMINO_H

class Tetromino
{
public:
	Tetromino(int, int);
	virtual void turn() = 0;
	virtual void generateCube() = 0;
	Tetromino & operator-=(Tetromino &);
	void draw();
	void deleCube();
	void printCube(int, int, int);
	int expectX(int);
	double expectY(double, int&);
	void setdata();
	void deleData(int, int);
	void dropData(int, int);
	void saveData(int, int);
	int expect(int, int&, double&);
	void deleline(int);
	void delePossibleLine();
	int getGrade();
protected:
	int width, height;
	int **drop_data;
	int **save_data;
	int lastcube[4][4];
	int cube[4][4];
	int lastx, lasty;
	int high[10];
};
#endif
