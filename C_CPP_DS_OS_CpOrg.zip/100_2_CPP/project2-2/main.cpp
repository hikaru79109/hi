//main.cpp
#include <iostream>
#include <ncurses/curses.h>
#include <ctime>
#include "Tetromino.h"
#include "T.h"
#include "J.h"
#include "S.h"
#include "O.h"
#include "I.h"
#include "L.h"
#include "Z.h"
#define SPACE 32
#define ENTER 10
#define ESC 27
using namespace std;

int randcube();
int randcube()
{
	srand(time(NULL));
	int k = rand()%7;  //亂數取七種方塊中的一種
	return k;
}

int main()
{
	Tetromino *cube;
	int width, height, grade;
	double v = 0.1, y = 0;
	int x = 42;
	int c, go = 0, drawing = 1, cc;
	int go_on1, go_on2, go_on;
	initscr(); // start curses mode
	cbreak(); // disable key buffering
	noecho(); // disable echoing
	nodelay(stdscr, TRUE);
	keypad(stdscr, TRUE); // enable keypad reading
	getmaxyx(stdscr, height, width); // get screen size

	start_color(); // color-start
	//set color
	init_pair(1, COLOR_CYAN, COLOR_CYAN);
	init_pair(2, COLOR_BLUE, COLOR_BLUE);
	init_pair(3, COLOR_GREEN, COLOR_GREEN);
	init_pair(4, COLOR_YELLOW, COLOR_YELLOW);
	init_pair(5, COLOR_MAGENTA, COLOR_MAGENTA);
	init_pair(6, COLOR_WHITE, COLOR_WHITE);	
	init_pair(7, COLOR_RED, COLOR_RED);

	mvaddstr(7,75,"PAUSE:Esc");
	mvaddstr(8,75,"Quit:Q");
	// time-start
	time_t t1, t2, t3, t;
	t1 = time(NULL); // get elapsed seconds since 1970/1/1 00:00:00

	go_on = TRUE;
	go_on1 = TRUE;
	go_on2 = TRUE;
	while (go_on) {
		y = 0;
		x = 42;
		t3 = 0;
		int temp = 0;
		int k = randcube();
		switch(k) {
			case 0:cube = new I(width,height); cube->printCube(y, x, k); break;// 產生方塊
			case 1:cube = new J(width,height); cube->printCube(y, x, k); break;// 產生方塊
			case 2:cube = new S(width,height); cube->printCube(y, x, k); break;// 產生方塊
			case 3:cube = new O(width,height); cube->printCube(y, x, k); break;// 產生方塊
			case 4:cube = new T(width,height); cube->printCube(y, x, k); break;// 產生方塊
			case 5:cube = new L(width,height); cube->printCube(y, x, k); break;// 產生方塊
			case 6:cube = new Z(width,height); cube->printCube(y, x, k); break;// 產生方塊
		}
		if (drawing == 1) {cube->draw(); drawing = 0;} // 畫邊界
		go_on1 = TRUE;
		go_on2 = TRUE;
		while (go_on1) {
			if (go == 1) {
				mvaddstr(20, 45, "PRESS ENTER");
				c = getch();
				switch (c) {
					case ENTER: go_on1 = TRUE; go_on2 = TRUE; mvaddstr(20, 45, "           "); break;
					default: continue;
				}
				go = 0;
			}
			while (go_on2) {
				while ((c = getch()) == ERR) {
					time(&t2);
					t = t2-t1;
					if (t3 != 0 && t2-t3 >= 2) {
						go_on1 = FALSE;
						go_on2 = FALSE;
						cube->saveData(y, x);
						break;
					}
					y += v / 1000;
					if (y > height-9) {
						y = cube->expectY(y, temp);
						if (temp == 1) time(&t3);
					}
					cube->deleCube();
					cube->printCube(y, x, k);
					cube->dropData(y, x);
					cc = cube->expect(0, x, y);
					if (cc == 0) {
						go_on1 = FALSE;
						go_on2 = FALSE;
						cube->saveData(y, x);
						break;
					}
					grade = cube->getGrade();
					move(4, 75);
					printw("time: %d sec", t);
					move(5, 75);
					printw("grade: %d", grade);
				} // while ((c = getch()) == ERR) 
				switch (c) {
					case KEY_LEFT: x-=4; x = cube->expectX(x); cc = cube->expect(2, x, y); break;
					case KEY_RIGHT: x+=4; x = cube->expectX(x); cc = cube->expect(1, x, y); break;
					case KEY_UP: cube->turn(); x = cube->expectX(x); break;
					case KEY_DOWN: y = y+1; y = cube->expectY(y, temp); break;
					case ESC: go_on2 = FALSE; go = 1; break;
					case SPACE: y = height; go_on2 = FALSE; go_on1 = FALSE; y = cube->expectY(y, temp);
								cube->dropData(y, x); 
								cc = cube->expect(3, x, y);
								cube->saveData(y, x); cube->deleCube(); cube->printCube(y, x, k); break;
					case 'q': go_on2 = FALSE; go_on1 = FALSE; go_on = FALSE; break;
					default: continue;
				} // switch (c)
			} // while (go_on2)
		} // while (go_on1)
		cube->delePossibleLine();
		delete cube;
	} // while (go_on)
	endwin();
}
