//Z.h
#ifndef MINO_Z_H
#define MINO_Z_H

#include "Tetromino.h"
using namespace std;

class Z : public Tetromino
{
public:
	Z(int &, int &);
	virtual void turn();
	virtual void generateCube();
	
private:
	int height, k;
	static const int type_cube_Z[4][4][4];
};
#endif
