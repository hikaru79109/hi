//L.h
#ifndef MINO_L_H
#define MINO_L_H

#include "Tetromino.h"
using namespace std;

class L : public Tetromino
{
public:
	L(int &, int &);
	virtual void turn();
	virtual void generateCube();
	
private:
	int height, k;
	static const int type_cube_L[4][4][4];
};
#endif
