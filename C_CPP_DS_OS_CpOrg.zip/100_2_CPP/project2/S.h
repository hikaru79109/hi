//S.h
#ifndef MINO_S_H
#define MINO_S_H

#include "Tetromino.h"
using namespace std;

class S : public Tetromino
{
public:
	S(int &, int &);
	virtual void turn();
	virtual void generateCube();
	
private:
	int height, k;
	static const int type_cube_S[4][4][4];
};
#endif
