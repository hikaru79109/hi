//I.h
#ifndef MINO_I_H
#define MINO_I_H

#include "Tetromino.h"
using namespace std;

class I : public Tetromino
{
public:
	I(int &, int &);
	virtual void turn();
	virtual void generateCube();
	
private:
	int height, k;
	static const int type_cube_I[4][4][4];
};
#endif
