//O.cpp
#include <iostream>
#include <cstdlib>
#include "O.h"
using namespace std;

const int O::type_cube_O[4][4] =
{
	{0,0,0,0},
	{0,1,1,0},
	{0,1,1,0},
	{0,0,0,0}
};

O::O(int &w, int &h)
	: Tetromino(w, h)
{
	height = h;
	lastx = 42;  //方塊產生時的位置
	lasty = 0;
	generateCube();
}

void O::generateCube()
{
	int i, j;
	for (i = 0; i < 4; ++i) { 
		for (j = 0; j < 4; ++j) {
			Tetromino::lastcube[i][j] = Tetromino::cube[i][j] = type_cube_O[i][j];
		}
	}
}

void O::turn(){}
