//J.h
#ifndef MINO_J_H
#define MINO_J_H

#include "Tetromino.h"
using namespace std;

class J : public Tetromino
{
public:
	J(int &, int &);
	virtual void turn();
	virtual void generateCube();
	
private:
	int height, k;
	static const int type_cube_J[4][4][4];
};
#endif
