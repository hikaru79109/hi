//O.h
#ifndef MINO_O_H
#define MINO_O_H

#include "Tetromino.h"
using namespace std;

class O : public Tetromino
{
public:
	O(int &, int &);
	virtual void generateCube();
	virtual void turn();

private:
	int height;
	static const int type_cube_O[4][4];
};
#endif
