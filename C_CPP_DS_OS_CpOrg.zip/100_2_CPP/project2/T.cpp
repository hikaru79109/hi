//T.cpp
#include <iostream>
#include <ncurses/curses.h>
#include <cmath>
#include <cstdlib>
#include "T.h"
using namespace std;

const int T::type_cube_T[4][4][4] =
{
	{
		{0,0,1,0},
		{0,1,1,1},
		{0,0,0,0},
		{0,0,0,0}
	},
	{
		{0,0,1,0},
		{0,0,1,1},
		{0,0,1,0},
		{0,0,0,0}
	},
	{
		{0,0,0,0},
		{0,1,1,1},
		{0,0,1,0},
		{0,0,0,0}
	},
	{
		{0,0,1,0},
		{0,1,1,0},
		{0,0,1,0},
		{0,0,0,0}
	}	
};

T::T(int &w, int &h)
	: Tetromino(w, h)
{
	height = h;
	lastx = 42;  //方塊產生時的位置
	lasty = 0;
	generateCube();
}

void T::generateCube()
{
	int i, j;
	initscr(); // start curses mode
	cbreak(); // disable key buffering
	noecho(); // disable echoing
	srand(time(NULL));
	k = rand()%4;  //亂數取四種狀態中的一種
	for (i = 0; i < 4; ++i) { 
		for (j = 0; j < 4; ++j) {
			Tetromino::lastcube[i][j] = Tetromino::cube[i][j] = type_cube_T[k][i][j];
		}
	}
}

	
void T::turn()
{
	int i, j;
	k++;
	if (k >= 4) k = 0;
	for (i = 0; i < 4; ++i) {
		for (j = 0; j < 4; ++j) {
			Tetromino::cube[i][j] = type_cube_T[k][i][j];
		}
	}
}
