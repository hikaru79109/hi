//HeartRates.cpp
//member-function definitions
#include <iostream>
#include "HeartRates.h"
using namespace std;

HeartRates::HeartRates( string firstname, string lastname, int birth_year, int birth_month, int birth_day, int curyear, int curmonth, int curday )
{
	setFirstName( firstname );
	setLastName( lastname );
	setBirth( birth_year, birth_month, birth_day );
	setCurrent( curyear, curmonth, curday );
}
void HeartRates::setFirstName( string firstname )
{
	FirstName = firstname;
}
void HeartRates::setLastName( string lastname )
{
	LastName = lastname;
}
void HeartRates::setBirth( int birth_year, int birth_month, int birth_day )
{
	BirthYear = birth_year;
	BirthMonth = birth_month;
	BirthDay = birth_day;
}
void HeartRates::setCurrent( int curyear, int curmonth, int curday )
{
	curYear = curyear;
	curMonth = curmonth;
	curDay = curday;
}
int HeartRates::getAge( int BirthYear, int BirthMonth, int BirthDay, int curYear, int curMonth, int curDay )
{
	if (curMonth < BirthMonth) {
		age = curYear - BirthYear - 1;
	}
	else if (curMonth == BirthMonth)
	{
		if (curDay < BirthDay) {
			age = curYear - BirthYear - 1;
		}
		else age = curYear - BirthYear;
	}
	else age = curYear - BirthYear;
	return age;
}
int HeartRates::getMaximumHeartRate(int age)
{
	maxHeartRate = 220 - age;
}
float HeartRates::getTargetHeartRate(int maxHeartRate, int i)
{
	if (i == 0) {
		targetHeartRate_low = maxHeartRate * 0.5; //lower
		return targetHeartRate_low;
	}
	else if (i == 1) {
		targetHeartRate_up = maxHeartRate * 0.85; //upper
		return targetHeartRate_up;
	}
}
