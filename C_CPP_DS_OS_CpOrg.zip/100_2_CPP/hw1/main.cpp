#include <iostream>
#include "HeartRates.h"
using namespace std;

int main()
{
	string firstname, lastname;
	int birth_year, birth_month, birth_day, curyear, curmonth, curday;
	cout << "firstname:";
	cin >> firstname;
	cout << "lastname:";
	cin >> lastname;
	cout << "birth(y m d):";
	cin >> birth_year >> birth_month >> birth_day;
	cout << "please enter the current date(year month day):";
	cin >> curyear >> curmonth >> curday;
	HeartRates heartrates( firstname, lastname, birth_year, birth_month, birth_day, curyear, curmonth, curday);
	int age, maxHeartRate;
	age = heartrates.getAge(birth_year, birth_month, birth_day, curyear, curmonth, curday);
	maxHeartRate = heartrates.getMaximumHeartRate(age);
	cout << "\nfirstname:" << firstname << "\nlastname:" << lastname << "\nbirth:" << birth_year << "/"								<< birth_month << "/" << birth_day;
	cout << "\nage:" << heartrates.getAge(birth_year, birth_month, birth_day, curyear, curmonth, curday) 							<< "\nmax heart rate:" << heartrates.getMaximumHeartRate(age) << "\ntarget heart rate:"										<< heartrates.getTargetHeartRate(maxHeartRate, 0) << "~" << heartrates.getTargetHeartRate(maxHeartRate, 1) << endl;
}
