//HeartRates.h
//class definition
#include <string>
using namespace std;

class HeartRates
{
public:
	HeartRates( string firstname, string lastname, int birth_year, int birth_month, int birth_day, int curyear, int curmonth, int curday );
	void setFirstName( string firstname );
	void setLastName( string lastname );
	void setBirth( int birth_year, int birth_month, int birth_day );
	void setCurrent( int curyear, int curmonth, int curday );
	int getAge( int BirthYear, int BirthMonth, int BirthDay, int curYear, int curMonth, int curDay );
	int getMaximumHeartRate(int age);
	float getTargetHeartRate(int maxHeartRate, int i);
private:
	string FirstName, LastName;
	int BirthYear, BirthMonth, BirthDay, curYear, curMonth, curDay, maxHeartRate, age;
	float targetHeartRate_low, targetHeartRate_up;
};
