#include <iostream>
#include <string>
using namespace std;

class HeartRates
{
public:
	HeartRates( string firstname, string lastname, int birth_year, int birth_month, int birth_day, int curyear, int curmonth, int curday )
	{
		setFirstName( firstname );
		setLastName( lastname );
		setBirth( birth_year, birth_month, birth_day );
		setCurrent( curyear, curmonth, curday );
	}
	void setFirstName( string firstname )
	{
		FirstName = firstname;
	}
	void setLastName( string lastname )
	{
		LastName = lastname;
	}
	void setBirth( int birth_year, int birth_month, int birth_day )
	{
		BirthYear = birth_year;
		BirthMonth = birth_month;
		BirthDay = birth_day;
	}
	void setCurrent( int curyear, int curmonth, int curday )
	{
		curYear = curyear;
		curMonth = curmonth;
		curDay = curday;
	}
	int getAge( int BirthYear, int BirthMonth, int BirthDay, int curYear, int curMonth, int curDay )
	{
		if (curMonth < BirthMonth) {
			age = curYear - BirthYear - 1;
		}
		else if (curMonth == BirthMonth)
		{
			if (curDay < BirthDay) {
				age = curYear - BirthYear - 1;
			}
			else age = curYear - BirthYear;
		}
		else age = curYear - BirthYear;
		return age;
	}
	int getMaximumHeartRate(int age)
	{
		maxHeartRate = 220 - age;
	}
	float getTargetHeartRate(int maxHeartRate, int i)
	{
		if (i == 0) {
			targetHeartRate_low = maxHeartRate * 0.5; //lower
			return targetHeartRate_low;
		}
		else if (i == 1) {
			targetHeartRate_up = maxHeartRate * 0.85; //upper
			return targetHeartRate_up;
		}
	}
private:
	string FirstName, LastName;
	int BirthYear, BirthMonth, BirthDay, curYear, curMonth, curDay, maxHeartRate, age;
	float targetHeartRate_low, targetHeartRate_up;
};
int main()
{
	string firstname, lastname;
	int birth_year, birth_month, birth_day, curyear, curmonth, curday;
	cout << "firstname:";
	cin >> firstname;
	cout << "lastname:";
	cin >> lastname;
	cout << "birth(y m d):";
	cin >> birth_year >> birth_month >> birth_day;
	cout << "please enter the current date(year month day):";
	cin >> curyear >> curmonth >> curday;
	HeartRates heartrates( firstname, lastname, birth_year, birth_month, birth_day, curyear, curmonth, curday);
	int age, maxHeartRate;
	age = heartrates.getAge(birth_year, birth_month, birth_day, curyear, curmonth, curday);
	maxHeartRate = heartrates.getMaximumHeartRate(age);
	cout << "\nfirstname:" << firstname << "\nlastname:" << lastname << "\nbirth:" << birth_year << "/"								<< birth_month << "/" << birth_day;
	cout << "\nage:" << heartrates.getAge(birth_year, birth_month, birth_day, curyear, curmonth, curday) 							<< "\nmax heart rate:" << heartrates.getMaximumHeartRate(age) << "\ntarget heart rate:"										<< heartrates.getTargetHeartRate(maxHeartRate, 0) << "~" << heartrates.getTargetHeartRate(maxHeartRate, 1) << endl;
}
