#include <iostream>
using namespace std;
#define insert 1
#define show 2
#define exit 3

typedef unsigned long int ULI;
typedef struct node {
	int data;
	node *link;
};

node *ins(node *pre, node *cur, int input)
{
	node *next;
	next = new node;
	next -> data = input;
	next -> link = cur;
	
	if (*first) {
		(*L) -> link = (node *)(ULI(pre) ^ ULI(cur));
		(*cur) -> link = (node *)(ULI(L) ^ 0);
		pre = L;
		L = cur;
	}
	else {
		(*cur) -> link = NULL;
		pre = L;
		L = cur;
		first = cur;
	}
	cout << "cur:" << cur << endl;
	cout << "pre:" << pre << endl;
	cout << "L:" << L << endl;
	
}

void printLToR(node **first, node **left)
{
	node *curr = NULL, *p_pre = NULL;
	cout << first << endl;
//	curr = *first;
//	&p_pre = left;
//	while (curr -> link != NULL) {
//		cout << curr -> data << " ";
//		&curr = (node *)(ULI(curr -> link) ^ (ULI(&curr) - ULI(&p_pre) + ULI(&curr)));
//	}
}

int main()
{
	char c;
	int input, go_on = true, choice;
	node *head = NULL, *tail = NULL;
	while (go_on) {
		cout << "Choice (1)insert (2)show list (3)exit : ";
		cin >> choice;
		if (choice == insert) {
			cin.get(c);
			while (cin.get(c) && c != '\n') {
				if (c == ' ') continue;
				input = c-'0';
				if (i++ == 0) 
					head = tail = ins(head, tail, input);
				else if (i++ == 1)
					tail = ins(NULL, tail, input);
				else
					tail = ins(tail -> link, tail, input);
			}
		}
		else if (choice == show) {
			printLToR(&first, &left);
		}
		else if (choice == exit) go_on = false;
		else continue;
	}
}
