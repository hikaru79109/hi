#include <iostream>
using namespace std;
#define insert 1
#define show 2
#define exit 3

typedef unsigned long int ULI;
typedef struct node {
	int data;
	node *link;
};

node *ins(node *pre, node *cur, int input)
{
	node *next;
	next = new node;
	next -> data = input;
	next -> link = cur;		//讓一開始的next指向原先儲存的link list尾巴指向的第一個node
	if (cur == NULL);		//輸入的第一筆資料
	else if (pre == NULL) {	//輸入的第二筆資料，因為是最左，pre還是NULL
		cur -> link = next;
		next -> link = cur;
	}
	else
		cur -> link = (node *)(ULI(pre) ^ ULI(next));	//將該格的link儲存該格前後位址的XOR
	return next;
}

void print(node *first)
{
	node *pre, *cur;
	cur = pre = first;		//讓cur和pre都與最左或最右的node相等
	while (cur) {
		cout << cur -> data << " ";
		if (cur -> link == cur) break;	//儲存的資料印完了
		if (cur == pre)
			cur = cur -> link;			//第一個的link直接指向下一個node
		else {
			node *temp = cur;			//其他的link儲存的都是前後位址的XOR
			cur = (node *)(ULI(pre) ^ ULI(cur -> link));
			pre = temp;
		}
	}
}

int main()
{
	char c;
	int input, go_on = true, choice, i = 0;
	node *head = NULL, *tail = NULL;
	while (go_on) {
		cout << "Choice (1)insert (2)show list (3)exit : ";
		cin >> choice;
		if (choice == insert) {
			cout << "input sequence: ";
			cin.get(c);
			while (cin.get(c) && c != '\n') {
				if (c == ' ') continue;
				input = c-'0';
				if (i++ == 0) 		//儲存第一筆資料
					head = tail = ins(head, tail, input);
				else if (i++ == 1)	//儲存第二筆資料
					tail = ins(NULL, tail, input);
				else				//儲存其他筆資料
					tail = ins(tail -> link, tail, input);
			}
		}
		else if (choice == show) {
			cout << "left to right:";
			print(head);
			cout << "\nright to left:";
			print(tail);
			cout << endl;
		}
		else if (choice == exit) go_on = false;
		else continue;
	}
}
