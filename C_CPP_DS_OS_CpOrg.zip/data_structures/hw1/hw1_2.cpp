//iterative
#include <iostream>
using namespace std;

int A(int m, int n)
{
	while (m != 0) {
		if (m > 0 && n == 0) {
			--m;
			n = 1;
		}
		else { 
			n = A(m, n-1);
			--m;
		}
	}
	++n;
	return n;
}

int main()
{
	int m = 0, n = 0, output = 0;
	cout << "請輸入m:";
	cin >> m;
	cout << "請輸入n:";
	cin >> n;
	output = A(m, n);
	cout << "A(" << m << "," << n << ") = " << output <<endl; 
}
