//recursive
#include <iostream>
using namespace std;

int A(int m, int n)
{
	if (m == 0) return n+1;
	else if (m > 0 && n == 0) return A(m-1, 1);
	else return A(m-1, A(m, n-1));
}

int main()
{
	int m = 0, n = 0, output = 0;
	cout << "請輸入m:";
	cin >> m;
	cout << "請輸入n:";
	cin >> n;
	output = A(m, n);
	cout << "A(" << m << "," << n << ") = " << output <<endl; 
}
