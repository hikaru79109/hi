//iterative, not complete
#include <iostream>
using namespace std;

int A(int m, int n)
{
	int k = 0, r[m], i = 0, mi = m, j = 0;
	for (j = 0; j < m; ++j) {
		r[j] = 0;
	}
	while (k != -1) {
		while (m != 0) {
			if (m > 0 && n == 0) {
				--m; 
				n = 1;
				++i;
			}
			while (m > 0 && n > 0) {
				--n;
				++k;
				++r[i];
			}
		}
		--i;
		for (++r[i]; r[i] > 0; --r[i]) { //m=0時n的變動
			++n;
			--k;
		}
		j = i;
		if (r[i-1] - mi + i + 1 == 0) --i;
		if (j == i) --r[i-1];
		m = mi - i;
	}
	return n;
}

int main()
{
	int m = 0, n = 0, output = 0;
	cout << "請輸入m:";
	cin >> m;
	cout << "請輸入n:";
	cin >> n;
	output = A(m, n);
	cout << "A(" << m << "," << n << ") = " << output <<endl; 
}
