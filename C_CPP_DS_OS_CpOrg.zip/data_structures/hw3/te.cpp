#include <iostream>
using namespace std;

void f(int b[])
{
	b[0] = 1;
}

int main()
{
	int b[10];
	f(b);
	cout << b[0] << endl;	
}
