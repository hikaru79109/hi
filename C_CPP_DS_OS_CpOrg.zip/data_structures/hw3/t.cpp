#include <iostream>
using namespace std;

void f(int *b)
{
	*b = 1;
}

int main()
{
	int b = 0;
	f(&b);
	cout << b << endl;	
}
