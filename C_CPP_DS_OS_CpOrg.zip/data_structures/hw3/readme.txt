�{���y���GC++
�sĶ���ҡGcygwin
�sĶ�覡�Gg++ -o hw3 hw3.cpp
����覡�G./hw3
�ާ@��k�G
	��Jn,m(bug[n][m]�An��m���ж�)
	��Jx,y(�_�l��m(x,y))

�{�������G
    �禡�G
	main():
		input n, m, x, y
		call move() to move and count total and bug[y][x]
		call print() to print out the result
	move():
		initialize bug[][] to 0
		get random k to determine the direction bug moves
		the bug move, and x, y change
		inspect if x and y move over the boundary
		inspect if all of the tiles have been touch or not
		if all of the tiles have been touch then return total
	print():
		print "The total number of legal moves"
		print how many times does each tile have been touch
		(0,0) for bug[0][0], (1,0) for bug[1][0], ......
		 -----------------
		|(0,0)|(0,1)|(0,2)......
		|-----|-----|-----
		|(1,0)|(1,1)|(1,2)......
		|-----|-----|-----
		|(2,0)|(2,1)|(2,2).....
		|-----|-----|-----
			�U
			�U
    �ܼơG
	total:
		total number of legal moves
	bug[n][m]:
		how many times does the tile at (n,m) the bug touches ((n,m) from (0,0) to (m-1,n-1))
	xmove[k]�Bymove[k]:
		8 directions:
		 _____________________
		|(-1,-1)|(0,-1)|(1,-1)|
		|-------|------|------|
		|(-1, 0)|      |(1, 0)|
		|-------|------|------|
		|(-1, 1)|(0, 1)|(1, 1)|
		 �áááááááááá�
		k=0:(-1,1)
		k=1:(-1,0)
		k=2:(-1,-1)
		k=3:(0,-1)
		k=4:(1,-1)
		k=5:(1,0)
		k=6:(1,1)
		k=7:(0,1)
		xmove=-1 for left shift, xmove=1 for right shift
		ymove=-1 for moving up, ymove=1 for moving down
		xmove=0 and ymove=0 for not to move