#include <iostream>
#include <ctime>
#include <iomanip>
#define MAX 50000
using namespace std;

int move(int n, int m, int x, int y, int bug[])
{
	int i, j;
	//initialize bug[][]
	for (i = 0; i < n; ++i) {
		for (j = 0; j < m; ++j) {
			bug[i*m+j] = 0;
		}
	}

	srand(time(NULL));
	int total = 0, k, xmove[8], ymove[8], stop = 1, go_on, inspect;
//8 directions
// _____________________
//|(-1,-1)|(0,-1)|(1,-1)|
//|-------|------|------|
//|(-1, 0)|      |(1, 0)|
//|-------|------|------|
//|(-1, 1)|(0, 1)|(1, 1)|
// ￣￣￣￣￣￣￣￣￣￣￣
	xmove[0] = -1;
	ymove[0] = 1;
	xmove[1] = -1;
	ymove[1] = 0;
	xmove[2] = -1;
	ymove[2] = -1;
	xmove[3] = 0;
	ymove[3] = -1;
	xmove[4] = 1;
	ymove[4] = -1;
	xmove[5] = 1;
	ymove[5] = 0;
	xmove[6] = 1;
	ymove[6] = 1;
	xmove[7] = 0;
	ymove[7] = 1;
	while (total < MAX && stop == 1) { //not to move over 50000 times
		k = rand()%8;
		x += xmove[k];
		y += ymove[k];
		go_on = 2;
		inspect = 1;
		while (go_on) {
			//illegal move
			if (x >= m) {--x; inspect = 0;}
			else if (y >= n) {--y; inspect = 0;}
			else if (x < 0) {++x; inspect = 0;}
			else if (y < 0) {++y; inspect = 0;}
			//legal move
			else if (inspect != 0) {
				++total;
				++bug[y*m+x];
				go_on = 1;
			}
			--go_on;
		}
		//if all of the tiles have been touch or not
		for (i = 0; i < n; ++i) {
			for (j = 0; j < m; ++j) {
				if (bug[i*m+j] == 0) {
					i += n;
					j += m;
				}
				else if (i == n-1 && j == m-1) stop = 0;
			}
		}
	} //end while, to check if the legal moves over 50000 times
	return total;
}

void print(int n, int m, int bug[], int total)
{
	int i = 0, j = 0;
	cout << "The total number of legal moves : " << total << endl;
	cout << " ";
	for (j = 0; j < m; ++j) {
		cout << "_____";
	}
		cout << endl;
	for (i = 0; i < n; ++i) {
		cout << "|";
		for (j = 0; j < m; ++j) {
			cout << setw(4) << bug[i*m+j] << "|";
		}
		cout << endl;
		for (j = 0; j < m; ++j) {
			cout << "|----";
		}
		cout << "|" << endl;
	}
}
		

int main()
{
	int n = 0, m = 0, x = -1, y = -1, total;

	while (n <= 2 || n > 40 || m < 2 || m > 20) {
		cout << "Input n:";
		cin >> n;
		cout << "Input m:";
		cin >> m;
	}
	while (x >= m || x < 0 || y >= n || y < 0) {
		cout << "input (x,y) within (0,0)~(m-1,n-1)" << endl;
		cout << "Input initial x:";
		cin >> x;
		cout << "Input initial y:";
		cin >> y;
	}
	int bug[n][m]; //to save how many times does the bug touch the tile(n-1,m-1)
	total = move(n, m, x, y, bug[0]);
	print(n, m, bug[0], total);
}
