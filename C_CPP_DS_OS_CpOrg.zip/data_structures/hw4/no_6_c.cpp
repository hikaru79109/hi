#include <iostream>
#include <fstream>
using namespace std;
#define MAX_SIZE 30
char stack[MAX_SIZE];

void stackFull()
{
	cout << "Stack is full!" << endl;
}

void stackEmpty()
{
	cout << "Stack is empty!" << endl;
}

void push(int item, int *top)
{
	if (*top >= MAX_SIZE-1)
		stackFull();
	stack[++(*top)] = item;
}

int pop(int *top)
{
	char temp;
	if (*top == -1) {
		stackEmpty();
		return 0;
	}
	else {
		temp = stack[*top];
		stack[*top] = '\0';
		--(*top);
		return temp;
	}
}

int isp(char token)
{
	switch (token) {
		case '(': return 19;
		case ')': return 0;
		case '+': return 12;
		case '-': return 12;
		case '*': return 13;
		case '/': return 13;
		case '%': return 13;
		case ' ': return 0;
	}
}

int icp(char token)
{
	switch (token) {
		case '(': return 19;
		case ')': return 0;
		case '+': return 12;
		case '-': return 12;
		case '*': return 13;
		case '/': return 13;
		case '%': return 13;
		case ' ': return 0;
	}
}

void infixToPrefix(char infix[], int *top, int size)
{
	int i = 0, pre_j = 0, paren = 0;
	stack[0] = ' ';
	char prefix[MAX_SIZE] = {0}, temp[MAX_SIZE] = {0};
	while (infix[i] != '\n') {
		if (isalpha(infix[i]))
			prefix[pre_j++] = infix[i++];
		else if (infix[i] == '(') {
			++paren;
			while (stack[*top] != ')')
				prefix[pre_j++] = pop(top);
			pop(top);
			++i;
		}
		else {
			while (icp(infix[i]) < isp(stack[*top]))
				prefix[pre_j++] = pop(top);
			push(infix[i++], top);
		}
	}
	while ((prefix[pre_j++] = pop(top)) != ' ');
	size = size-2*paren;
	for (i = 0; i < size; ++i) temp[i] = prefix[size-i-1];
	cout << "output:" << temp << endl;
}

int main()
{
	int top = 0;
	char filename[10];
	cout << "input file's name:";
	cin >> filename;
	while (sizeof(filename) > 10) {
		cout << "too long!\ninput file's name:";
		cin >> filename;
	}
	ifstream input(filename, ios::in);

	if (!input) {
		cerr << "File can not be opened!" << endl;
		exit(1);
	}

	int i = 0, j = 0, line = 0;
	char infix[MAX_SIZE] = {0}, temp[MAX_SIZE] = {0};
	cin.get();
	cout << "input:";
	while ((infix[i] = input.get()) != EOF) {
		if (infix[i] == '\n') {	//there are i char in the line
			for (j = 0; j < i; ++j)
				temp[j] = infix[i-j-1];
			for (j = 0; j < i; ++j)
				infix[j] = temp[j];
			cout << endl;
			infixToPrefix(infix, &top, i);
			i = 0;
			top = 0;
			continue;
		}
		cout << infix[i];
		++i;
	}
}
