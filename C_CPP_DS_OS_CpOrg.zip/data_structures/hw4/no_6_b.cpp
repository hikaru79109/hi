#include <iostream>
#include <fstream>
using namespace std;
#define MAX_SIZE 30
char stack[MAX_SIZE];

void stackFull()
{
	cout << "Stack is full!" << endl;
}

void stackEmpty()
{
	cout << "Stack is empty!" << endl;
}

void push(int item, int *top)
{
	if (*top >= MAX_SIZE-1)
		stackFull();
	stack[++(*top)] = item;
}

int pop(int *top)
{
	char temp;
	if (*top == -1) {
		stackEmpty();
		return 0;
	}
	else {
		temp = stack[*top];
		stack[*top] = '\0';
		--(*top);
		return temp;
	}
}

int eval(char prefix[], int *top)
{
	int op1, op2, i = 0;
	while (prefix[i] != '\n') {
		if (isdigit(prefix[i]))
			push(prefix[i] - '0', top);
		else if(prefix[i] == ' ') {++i; continue;}
		else {
			op1 = pop(top);
			op2 = pop(top);
			switch (prefix[i]) {
				case '+': push(op1+op2, top);
						  break;
				case '-': push(op1-op2, top);
						  break;
				case '*': push(op1*op2, top);
						  break;
				case '/': push(op1/op2, top);
						  break;
				case '%': push(op1%op2, top);
						  break;
			}
		}
		++i;
	}
	return pop(top);
}

int main()
{
	int top = -1;
	char filename[10];
	cout << "input file's name:";
	cin >> filename;
	ifstream input(filename, ios::in);

	if (!input) {
		cerr << "File can not be opened!" << endl;
		exit(1);
	}

	char prefix[MAX_SIZE] = {0}, temp[MAX_SIZE] = {0};
	int i = 0, j = 0, line = 0;
	cin.get();
	while (input.getline(prefix, MAX_SIZE)) ++line;
	int result[line];
	line = 0;
	input.clear();
	input.seekg(0);
	while ((prefix[i] = input.get()) != EOF) {
		if (prefix[i] == '\n') {
			for (j = 0; j < i; ++j)
				temp[j] = prefix[i-j-1];
			for (j = 0; j < i; ++j)
				prefix[j] = temp[j];
			result[line] = eval(prefix, &top);
			cout << " = " << result[line] << endl;
			i = 0;
			top = -1;
			++line;
			continue;
		}
		cout << prefix[i];
		++i;
	}
}
