#include <iostream>
#include <ctime>
#define left 1
#define right 2
using namespace std;

void createQ(int size, int *deque)
{
	deque = new int[size];
}

void initialQ(int size, int deque[])
{
	for (int i = 0; i < size; ++i) {
		deque[i] = -1;
	}
}

void IsEmptyQ()
{
	cout << "\nThe queue is empty!\n" << endl;
}

void IsFullQ()
{
	cout << "\nThe queue is full!\n" << endl;
}

void addQ(int *front, int *rear, int deque[], int input, int size)
{
	int side;
	if (*front == -1 && *rear == size-1) {
		IsFullQ();
		side = 0;
	}
	else if (*front == -1) side = right;
	else if (*rear == size-1) side = left;
	else side = rand()%2+1;

	if (side == left) deque[(*front)--] = input;
	else if (side == right) deque[++(*rear)] = input;
}

void deleteQ(int *front, int *rear, int deque[], int side)
{
	if (*front == *rear) IsEmptyQ();
	else {
		if (side == left) deque[++(*front)] = -1;
		else if (side == right) deque[(*rear)--] = -1;
	}
}

void printQ(int size, int deque[])
{
	cout << "show array:";
	for (int i = 0; i < size; ++i) {
		if (deque[i] != -1) cout << deque[i] << " ";
	}
	cout << endl;
}

int main()
{
	srand(time(NULL));
	char do_what;
	int side, size = 0, *deque, input, go_on1 = 1, go_on2 = 1, i = 0;
	cout << "Enter array size:";
	cin >> size;
	createQ(size, deque);
	initialQ(size, deque);
	int front = size/2, rear = size/2;

	while (go_on1) {
		cout << "front:" << front << "/rear:" << rear << endl;
		cout << "choice (1)add (2)delete (3)exit:";
		cin >> do_what;
		go_on2 = 1;
		if (do_what == '1') {
			cout << "input sequence:";
			cin >> input;
			addQ(&front, &rear, deque, input, size);
		}
		else if (do_what == '2') {
			while (go_on2) {
				cout << "delete (1)left (2)right:";
				cin >> side;
				if (side == left || side == right) {
					deleteQ(&front, &rear, deque, side);
					go_on2 = 0;
				}
			}
		}
		else if (do_what == '3') go_on1 = 0;
		else continue;
		printQ(size, deque);
	}
}
