�{���y���GC++
�sĶ���ҡGcygwin
�sĶ�覡�Gg++ -o hw9_1 hw9_1.cpp
����覡�G./hw9_1
�{���\��GRewrite function DFS so that it works on INC
�{�������G
#include <iostream>
#include <fstream>
#define MAX_SIZE 50
using namespace std;

int **inc;
int t = 0;

void dfs(int numV, int numE, int v, int e)
{   //depth first search of a graph beginning at v
    int count = 0, i, j;
    i = v;
    for (j = e; j < numE; ++j) {
        if (inc[i][j] == 1 && count == 0) {
            ++count;
            ++i;
            --j;
        }
        else if (inc[i][j] == 1 && count == 1) {
            --count;
            cout << "e" << j;
            if (t++ < numE-2) cout << " -> ";
            dfs(numV, numE, i, j+1);
        }
        else if (count == 1) {++i; --j;}
        else continue;
    }
    if (v != 3) dfs(numV, numE, 0, e);
    else {
        cout << endl;
        exit(1);
    }
}

int main()
{
    char filename[10], temp[MAX_SIZE];
    int numV = 0, numE = 0, i, j;
    //int **inc;
    cout << "File's name:";
    cin >> filename;
    ifstream input(filename, ios::in);

    if (!input) {
        cerr << "File can not be opened!" << endl;
        exit(1);
    }

//count how many lines(numV)
    while (input.getline(temp, MAX_SIZE)) ++numV;
//back to the file's head
    input.clear();
    input.seekg(0);
//count how many item are there in a line(numE)
    while ((temp[0] = input.get()) != '\n') {
        if (temp[0] == '\t') continue;
        else ++numE;
    }
//back to the file's head
    input.clear();
    input.seekg(0);

//allocate inc[numV][numE]
    inc = new int *[numV];
    for (i = 0; i < numV; ++i) {
        inc[i] = new int[numE];
    }
//assign value into inc
    i = 0;
    j = 0;
    while ((temp[0] = input.get()) != EOF) {
        if (temp[0] == '\t') continue;
        if (temp[0] == '\n') {++i; j = 0;}
        else inc[i][j++] = temp[0] - '0';
    }

    cout << "Input:" << endl;
    for (i = 0; i < numV; ++i) {
        for (j = 0; j < numE; ++j) {
            cout << inc[i][j] << "  ";
        }
        cout << endl;
    }
    cout << "\nOutput: ";
    dfs(numV, numE, 0, 0);
}
-----------------------------------------------------------------------------------------------
***********************************************************************************************
-----------------------------------------------------------------------------------------------
�{���y���GC++
�sĶ���ҡGcygwin
�sĶ�覡�Gg++ -o hw9_2 hw9_2.cpp
����覡�G./hw9_2
�{���\��Ginputs an AOE network and outputs:
		(a)earliest and latest times
		(b)early times and late times
		(c)critical vertex
�{�������G
#include <iostream>
#include <iomanip>
using namespace std;

int ee[10] = {0}, le[10] = {0};
int e[10] = {0}, l[10] = {0};
int start[14] = {0}, end[14] = {0}, a[14] = {0};
int max(int, int);
int min(int, int, int);
int EE(int [][10], int);
int LE(int [][10], int);
void printET(int [][10]);
void printLT(int [][10]);
void critical(int [][10]);

int main()
{
    int i, j;
    int input[10][10] = {{0,5,6,0,0,0,0,0,0,0},
                        {0,0,0,3,0,0,0,0,0,0},
                        {0,0,0,6,3,0,0,0,0,0},
                        {0,0,0,0,3,4,4,0,0,0},
                        {0,0,0,0,0,0,1,4,0,0},
                        {0,0,0,0,0,0,0,0,0,4},
                        {0,0,0,0,0,0,0,0,5,0},
                        {0,0,0,0,0,0,0,0,2,0},
                        {0,0,0,0,0,0,0,0,0,2},
                        {0,0,0,0,0,0,0,0,0,0}};
    cout << "Input matrix:" << endl;
    for (i = 0; i < 10; ++i) {
        for (j = 0; j < 10; ++j) {
            cout << input[i][j];
            if (j < 9) cout << ",";
        }
        cout << endl;
    }

    EE(input, 9);
    LE(input, 0);

    cout << "\nOutput:" << endl;
    cout << "(a)" << "\t";
    for (i = 0; i < 10; ++i)
        cout << left << "V" << setw(2) << i;
    cout << endl;
    cout << "\t";
    for (i = 0; i < 10; ++i)
        cout << setw(3) << ee[i];
    cout << "\t" << "earliest" << endl;
    cout << "\t";
    for (i = 0; i < 10; ++i)
        cout << setw(3) << le[i];
    cout << "\t" << "latest\n" << endl;
    printET(input);
    printLT(input);
    critical(input);
}

int max(int i1, int i2)
{
    if (i1 >= i2) return i1;
    else return i2;
}

int min(int i1, int i2, int i3)
{
    if (i1 <= i2) {
        if (i1 <= i3) return i1;
        else return i3;
    }
    else {
        if (i2 <= i3) return i2;
        else return i3;
    }
}

int EE(int input[][10], int j) //EarliestEvent
{
    if (ee[j] == 0) {
        int i = j-1, k = 0, tempEE[2] = {0};
        while (i >= 0) {
            if (input[i][j] != 0) {
                tempEE[k++] = EE(input, i) + input[i][j];
            }
            --i;
        }
        ee[j] = max(tempEE[0], tempEE[1]);
    }
    return ee[j];
}

int LE(int input[][10], int i) //LatestEvent
{
    le[9] = ee[9];
    if (le[i] == 0) {
        int j = i+1, k = 0, tempLE[3] = {25, 25, 25};
        while (j < 10) {
            if (input[i][j] != 0) {
                tempLE[k++] = LE(input, j) - input[i][j];
            }
            ++j;
        }
        le[i] = min(tempLE[0], tempLE[1], tempLE[2]);
    }
    return le[i];
}

void printET(int input[][10]) //earliest time
{
    int i, j, k = 1;
    cout << "(b)" << "\t";
    for (i = 1; i < 15; ++i)
        cout << "a" << setw(3) << i;
    cout << endl;
    cout << "\t";
    for (i = 0; i < 10; ++i)
        for (j = 0; j < 10; ++j)
            if (input[i][j] != 0) {
                e[k] = ee[i];
                cout << setw(4) << e[k++];
        }
    cout << "  earliest" << endl;
}

void printLT(int input[][10]) //latest time
{
    int i, j, k = 1;
    cout << "\t";
    for (i = 0; i < 10; ++i)
        for (j = 0; j < 10; ++j)
            if (input[i][j] != 0) {
                l[k] = le[j]-input[i][j];
                cout << setw(4) << l[k++];
            }
    cout << "  latest" << endl;
}

void critical(int input[][10])
{
    int k = 1, i, j;
    while (k < 15) {
        if (l[k]-e[k] == 0) ++a[k];
        ++k;
    }
    k = 1;
    for (i = 0; i < 10 && k < 15; ++i)
        for (j = 0; j < 10; ++j) {
            if (input[i][j] != 0 && a[k] > 0) {
                start[k] = i;
                end[k] = j;
            }
            else {
                start[k] = -1;
                end[k] = -1;
            }
        }
}
-----------------------------------------------------------------------------------------------
***********************************************************************************************
-----------------------------------------------------------------------------------------------
(d)
change a2 = 6 �� a2 = 5, length reduced to 22
change a4 = 6 �� a4 = 5, length reduced to 22
change a14 = 2 �� a14 = 1, length reduced to 22