#include <iostream>
#include <fstream>
#define MAX_SIZE 50
using namespace std;

int **inc;
int t = 0;

void dfs(int numV, int numE, int v, int e)
{	//depth first search of a graph beginning at v
	int count = 0, i, j;
	i = v;
	for (j = e; j < numE; ++j) {
		if (inc[i][j] == 1 && count == 0) {
			++count;
			++i;
			--j;
		}
		else if (inc[i][j] == 1 && count == 1) {
			--count;
			cout << "e" << j;
			if (t++ < numE-2) cout << " -> ";
			dfs(numV, numE, i, j+1);
		}
		else if (count == 1) {++i; --j;}
		else continue;
	}
	if (v != 3) dfs(numV, numE, 0, e);
	else {
		cout << endl;
		exit(1);
	}
}

int main()
{
	char filename[10], temp[MAX_SIZE];
	int numV = 0, numE = 0, i, j;
	//int **inc;
	cout << "File's name:";
	cin >> filename;
	ifstream input(filename, ios::in);

	if (!input) {
		cerr << "File can not be opened!" << endl;
		exit(1);
	}

//count how many lines(numV)
	while (input.getline(temp, MAX_SIZE)) ++numV;
//back to the file's head
	input.clear();
	input.seekg(0);
//count how many item are there in a line(numE)
	while ((temp[0] = input.get()) != '\n') {
		if (temp[0] == '\t') continue;
		else ++numE;
	}
//back to the file's head
	input.clear();
	input.seekg(0);

//allocate inc[numV][numE]
	inc = new int *[numV];
	for (i = 0; i < numV; ++i) {
		inc[i] = new int[numE];
	}
//assign value into inc
	i = 0;
	j = 0;
	while ((temp[0] = input.get()) != EOF) {
		if (temp[0] == '\t') continue;
		if (temp[0] == '\n') {++i; j = 0;}
		else inc[i][j++] = temp[0] - '0';
	}

	cout << "Input:" << endl;
	for (i = 0; i < numV; ++i) {
		for (j = 0; j < numE; ++j) {
			cout << inc[i][j] << "	";
		}
		cout << endl;
	}
	cout << "\nOutput: ";
	dfs(numV, numE, 0, 0);
}
