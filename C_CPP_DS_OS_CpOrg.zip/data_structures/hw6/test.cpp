#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main( void )
{
long i = 10000000L;
clock_t start, finish;
double duration, a = 0;
cout << "\na:" << a << endl;
/* 測量一個事件持續的時間*/
cout << "Time to do " << i << " empty loops is ";
start = clock();
while( i-- ) ;
finish = clock();
duration = (double)(finish - start) / CLOCKS_PER_SEC;
cout << duration <<" seconds" << endl;
}
