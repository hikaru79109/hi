/*change the priority of an arbitrary element from a max heap*/

#include <iostream>
#include <sys/time.h>
#include <fstream>
#include <ctime>
#include <cstdio>
#include <cmath>
#define MAX_SIZE 200
using namespace std;

int heap[MAX_SIZE];
int n = 0, size = 0;

int heapIsFull()
{
	if (n == MAX_SIZE-1) {
		cout << "The heap is full!" << endl;
		return 1;
	}
	else return 0;
}

void push(int item)
{
	int i = 0;
	i = ++n;
	if (!heapIsFull()) {
		while ((i != 1) && (item > heap[i/2])) {
			heap[i] = heap[i/2];
			i /= 2;
		}
		heap[i] = item;
	}
}

int check(int item)
{
	for (int j = 1; j <= size; ++j)
		if (heap[j] == item) return j;
	cout << "There's no " << item << " in the max heap!" << endl;
	return 0;
}

void change(int pre, int cur)
{
	int j;
	if (j = check(pre)) {
		int parent = j, child = j * 2;
		int temp = heap[n];
		if (child <= n) {
			while (child <= n) {
				if ((child < n) && (heap[child] < heap[child+1]))
					++child;
				heap[parent] = heap[child];
				parent = child;
				child *= 2;
			}
			for (int j = 1; j <= size; ++j)
				cout << heap[j] << " ";
			cout << "cur:" << cur << endl;
			--n;
			push(cur);
		}
		else {
			heap[parent] = temp;
			int i = 0;
			i = j;
			while ((i != 1) && (cur > heap[i/2])) {
				heap[i] = heap[i/2];
				i /= 2;
			}
			heap[i] = cur;
		}
	}
}

int main()
{
	char filename[20];
	cout << "File's name:";
	cin >> filename;
	ifstream inputFile(filename, ios::in);

	if (!inputFile) {
		cerr << "File can't be opened!" << endl;
		exit(1);
	}

	struct timeval tv, tv2;
	double start, end;

	int i = 0, go_on = 1, pre_priority, cur_priority, counter = 0;
	char yn, input[MAX_SIZE] = {0};
	while ((input[i] = inputFile.get()) != EOF) {
		if (isdigit(input[i]))
			++i;
		else {
			int temp = i;
			float item = 0, k = 0;
			while (k < i-counter) {
				item += (input[--temp]-'0')*pow(10, k);
				++k;
			}
			push(item);
			++size;
			counter = ++i;
		}
	}
	cout << "Max Heap:";
	for (int j = 1; j <= size; ++j)
		cout << heap[j] << " ";
	cout << endl;
	while (go_on) {
		cout << "Change priority ?(Y/N):";
		cin >> yn;
		if (yn == 'y' || yn == 'Y') {
			cout << "Choice priority:";
			cin >> pre_priority;
			cout << "Change priority to:";
			cin >> cur_priority;
			gettimeofday(&tv, NULL);
			start = ((double)tv.tv_sec+(double)tv.tv_usec/1000000);
			change(pre_priority, cur_priority);
			usleep(1000);
			gettimeofday(&tv2, NULL);
			end = ((double)tv2.tv_sec+(double)tv2.tv_usec/1000000);
			cout << "Max Heap:";
			for (int j = 1; j <= size; ++j)
				cout << heap[j] << " ";
			cout << "\nSpend time:" << end-start << endl;
		}
		else if (yn == 'n' || yn == 'N') {
			cout << "Press any key to continue..." << endl;
			go_on = 0;
			cin.get();
			getchar();
		}
		else continue;
	}
}
