#include <iostream>
#include <fstream>
#include <cmath>
#define MAX_SIZE 100
using namespace std;

int sn;
void merge(int [], int [], int, int, int);
int pre(int [], int, int []);
void mergePass(int [], int [], int [], int);
void mergeSort(int [], int, int []);

int main()
{
	int i = 0, c = 0, j = 0, init[MAX_SIZE] = {0}, input[MAX_SIZE] = {0};
	ifstream inputFile("set.txt", ios::in);
	if (!inputFile) {
        cerr << "File can not be opened!" << endl;
        exit(1);
    }
	while ((input[i] = inputFile.get()) != EOF) {
		if (isdigit(input[i++])) ++c;		//c is counter that count how many numbers between comma
		else {								//ex: 5,11,6
			int t = i - 1;					//       ^^
			float k = 0, temp = 0;			//       ||
											//       |i
											//       t start here
			while (k < c) temp += (input[--t] - '0') * pow (10, k++);
			c = 0;
			init[j++] = temp;
		}
	}
	int num = j;				//總共有幾個數字要排
	int temp[j], n;				//temp用來暫存s，因為segment有幾個還未定
	sn = pre(init, num, temp);	//segment有sn個
	int s[n];
	for (i = 0; i < sn; ++i)
		s[i] = temp[i];
	mergeSort(init, num, s);	//init is input array; after mergeSort(), init is output array
//print sorted number
	for (i = 0; i < num; ++i)
		cout << init[i] << " ";
	cout << endl;
}

void mergeSort(int a[], int n, int s[])
{
	int extra[MAX_SIZE];

	while (s[0] < n) {
		mergePass(a, extra, s, n);
		mergePass(extra, a, s, n);
	}
}

void mergePass(int initList[], int mergedList[], int s[], int n)
{
	int i = 0, j = 0, k, temp;
	for (; i <= n - s[sn-2] - s[sn-1]; i = i + s[j] + s[j+1], j += 2)
		merge(initList, mergedList, i, i + s[j] - 1, i + s[j] + s[j+1] - 1);
	for (k = i; k < n; ++k)				//before merge: 5,7 | 3 | 1,2,8 | 6 | 4
		mergedList[k] = initList[k];	//after merge : 3,5,7 | 1,2,6,8
//處理segment有幾個						  after for(k): 3,5,7 | 1,2,6,8 | 4
	if (sn % 2) {		//sn is odd number
		sn = sn / 2 + 1;
		for (i = 0; i < sn-1; ++i)
			s[i] = s[2*i] + s[2*i+1];
		s[sn-1] = s[2*i];
	}
	else {				//sn is even number
		sn /= 2;
		for (i = 0; i < sn; ++i)
			s[i] = s[2*i] + s[2*i+1];
	}
}

void merge(int initList[], int mergedList[], int i, int m, int n)
{
	//    i    m  j    n
	//￣￣|￣￣|￣|￣￣|￣￣
	//￣￣ ￣￣ ￣ ￣￣ ￣￣
	int j, k, t;
	j = m+1;	//j is index for the second sublist
	k = i;		//k is index for merged list

	while (i <= m && j <= n) {
		if (initList[i] <= initList[j])
			mergedList[k++] = initList[i++];
		else
			mergedList[k++] = initList[j++];
	}
	if (i > m) 
		for (t = j; t <= n; ++t)
			mergedList[t] = initList[t];
	else
		for (t = i; t <= m; ++t)
			mergedList[k+t-i] = initList[t];
}

int pre(int init[], int num, int s[])
{
	int i = 0, j = 0;
	while (i < num-1) {
		if (init[i] < init[++i]);
		else s[j++] = i-1;
	}
//原本的s是segment最後一個的位置
//處理s將它改為segment的大小
	s[j] = num - 1 - s[j-1];
	for (i = j-1; i > 0; --i)
		s[i] = s[i] - s[i-1];
	s[0] += 1;

	return j+1;
}
