/* server.c */

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/times.h>
#include <sys/fcntl.h>
#include <netinet/in.h>
#include <string.h>
#include <stdlib.h>

#define MAXBUF 1024
#define MAXSOCK 10

int port = 8000;

int main(void)
{
	int mySock, newSock, connectedSock[MAXSOCK], banSock[MAXSOCK][MAXSOCK], busy[MAXSOCK];
	int clientAddrSize, onlineNum = 0, fd, fd2, idRInt, idSInt;
	struct sockaddr_in sockAddr_server, sockAddr_client;
	fd_set rfds;
	struct timeval tv;
	int retval, maxfd = -1;
	char buf[MAXBUF+1], msg[MAXBUF], msg2[MAXBUF] = "none", warn[MAXBUF];
	char *str1, *str2, idSChar[10];

	bzero(&sockAddr_server, sizeof(sockAddr_server));  //將一段內存內容全清為零
	sockAddr_server.sin_family = AF_INET;
	sockAddr_server.sin_port = htons(port);
	sockAddr_server.sin_addr.s_addr = htonl(INADDR_ANY);

	// server - socket
	mySock = socket(AF_INET, SOCK_STREAM, 0);
	if (mySock == -1) {
		perror("socket failed");
		exit(1);
	}

	// server - bind
	if (bind(mySock, (struct sockaddr *)&sockAddr_server, sizeof(sockAddr_server)) == -1) {
		perror("bind failed");
		exit(1);
	}

	// server - listen
	if (listen(mySock, 5) == -1) {
		perror("listen failed");
		exit(1);
	}

	printf("Accepting connections ...\n");

	clientAddrSize = sizeof(struct sockaddr_in);

	// initialize
	for (fd = 0; fd < MAXSOCK; ++fd) {
		connectedSock[fd] = 0; // not online
		busy[fd] = 0; // not busy
		for (fd2 = 0; fd2 < MAXSOCK; ++fd2) {
			if (fd == fd2) banSock[fd][fd2] = 1; // self is banned
			else banSock[fd][fd2] = 0; // no one is banned
		}
	}

	while (1) {
		FD_ZERO(&rfds);
		FD_SET(mySock, &rfds);
		tv.tv_sec = 1;
		tv.tv_usec = 0;
		for (fd = 0; fd < MAXSOCK; ++fd) {
			// add online client to SET
			if (connectedSock[fd]) FD_SET(fd, &rfds);
		}
		retval = select(MAXSOCK, &rfds, NULL, NULL, &tv);
		if (retval == 0) continue;	// no msg
		for (fd = 0; fd < MAXSOCK; ++fd) {
			if (FD_ISSET(fd, &rfds)) {
				if (mySock == fd) {
					if ((newSock = accept(mySock, (struct sockaddr *)&sockAddr_client, &clientAddrSize)) < 0) {
						perror("accept failed");
						exit(1);
					}
					++onlineNum; // num of online clients
					// send total user to client
					sprintf(msg, "Total:%d", onlineNum);
					strcat(msg, "\\Server");
					send(newSock, msg, sizeof(msg), 0);

					// send online users to client
					bzero(msg, sizeof(msg));
					strcat(msg, "User:");
					for (fd = 0; fd < MAXSOCK; ++fd) {
						if (connectedSock[fd] == 1) sprintf(msg2, "%d/", fd);
					}
					strcat(msg, msg2);
					strcat(msg, "\\Server");
					send(newSock, msg, sizeof(msg), 0);

					connectedSock[newSock] = 1; // client(newSock) is online
					printf("Accept from %d!\n", newSock);
				}
				else {
					bzero(buf, sizeof(buf));
					if (recv(fd, buf, sizeof(buf), 0) <= 0) {
						printf("connect close\n");
						connectedSock[fd] = 0; // client(fd) is offline
						--onlineNum;
						close(fd);
					}
					else {
						/*	|	function		|	command
						----------------------------------
						1)	|	send msg to idR	|	idR\msg
						2)	|	send msg to all	|	all\msg
						3)	|	ban idR			|	ban\idR
						4)	|	unban idR		|	unban\idR
						5)	|	state - busy	|	busy\
						6)	|	state - unbusy	|	unbusy\
						7)	|	user's state	|	state\
						*/

						// split the msg(buf)
						str1 = strtok(buf, "\\");
						str2 = strtok(NULL, "\\");
						sprintf(idSChar, "%d", fd); // idSChar: sender's id(char)
						idSInt = fd; // idSInt: sender's id(int)
						printf("S:%d R:%s M:%s\n", idSInt, str1, str2);

						//---------------- Ban ------------------
						if(!strcmp(str1, "ban")) {
							idRInt = atoi(str2); // idRInt: receiver's id(int)
							banSock[idSInt][idRInt] = 1;
						}
						//---------------- Unban ------------------
						else if(!strcmp(str1, "unban")) {
							idRInt = atoi(str2); // idRInt: receiver's id(int)
							banSock[idSInt][idRInt] = 0;
						}
						//---------------- Busy ------------------
						else if(!strcmp(str1, "busy")) {
							busy[idSInt] = 1;
						}
						//---------------- Unbusy ------------------
						else if(!strcmp(str1, "unbusy")) {
							busy[idSInt] = 0;
						}
						//---------------- State ------------------
						else if(!strcmp(str1, "state")) {
							for (fd2 = 0; fd2 < MAXSOCK; ++fd2) {
								bzero(warn, sizeof(warn));
								// if not self
								if (idSInt != fd2) {
									// if ban
									if (banSock[idSInt][fd2] == 1) {
										sprintf(warn, "%d banned\\Server", fd2);
										send(fd, warn, sizeof(warn), 0);
										continue;
									}
									// if online
									if (connectedSock[fd2] == 0) {
										sprintf(warn, "%d offline\\Server", fd2);
										send(fd, warn, sizeof(warn), 0);
										continue;
									}
									// if busy
									if (busy[fd2] == 1) {
										sprintf(warn, "%d busy\\Server", fd2);
										send(fd, warn, sizeof(warn), 0);
									}
									else {
										sprintf(warn, "%d online\\Server", fd2);
										send(fd, warn, sizeof(warn), 0);
									} // end else (unbusy)
								} // end if (not self)
							} // end for loop (user 0 ~ 9)
						}
						//---------------- Send ------------------
						else {
							bzero(warn, sizeof(warn));

							// add " idS" to sending msg's tail
							strcat(str2, "\\");
							strcat(str2, idSChar);

							//---------------- Send to all ------------------
							if (!strcmp(str1, "all")) {
								for (fd2 = 0; fd2 < MAXSOCK; ++fd2) {
									if (idSInt != fd2) // not self
										if (connectedSock[fd2] == 1) // online
											if (banSock[fd2][idSInt] == 0 && banSock[idSInt][fd2] == 0) send(fd2, str2, sizeof(str2), 0); // unbanned
								}
								continue;
							}

							idRInt = atoi(str1); // receiver's id(int)

							// inspect if online
							if (connectedSock[idRInt] == 0) {
								sprintf(warn, "%d is offline!\\Server", idSInt);
								send(idSInt, warn, sizeof(warn), 0);
								continue;
							}

							// inspect if ban
							if (banSock[idRInt][idSInt] == 1) continue; // receiver has banned sender
							else if (banSock[idSInt][idRInt] == 1) { // sender has banned receiver
								sprintf(warn, "You have banned %d!\\Server", idRInt);
								send(idSInt, warn, sizeof(warn), 0);
								continue;
							}

							// inspect if busy
							else if (busy[idRInt] == 1) {
								sprintf(warn, "%d is busy!\\Server", idRInt);
								send(idSInt, warn, sizeof(warn), 0);
							}

							//---------------- Send to idRInt ------------------
							idRInt = atoi(str1); // receiver's id
							send(idRInt, str2, sizeof(str2), 0);
						}
					}
				}
			}
		}
	}
}
