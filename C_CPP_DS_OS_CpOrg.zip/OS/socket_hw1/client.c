/* client.c */
/*	  |	function		|	command
	----------------------------------
	1)|	send msg to idR	|	idR\msg
	2)|	send msg to all	|	all\msg
	3)|	ban idR			|	ban\idR
	4)|	unban idR		|	unban\idR
	5)|	state - busy	|	busy\
	6)| state - unbusy	|	unbusy\
	7)| user's state	|	state\
	8)|	quit			|	\quit
*/

#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdlib.h>
#include <string.h>

#define MAXBUF 1024

int port = 8888;

int main(void)
{
	int serverSock, len;
	struct sockaddr_in serverAddr;
	char buffer[MAXBUF+1], *str1, *str2;
	fd_set rfds;
	struct timeval tv;
	int retval, maxfd = -1;

	bzero(&serverAddr, sizeof(serverAddr));  //將一段內存內容全清為零
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(port);
	serverAddr.sin_addr.s_addr = inet_addr("10.0.2.15");

	// serverAddr - socket
	serverSock = socket(AF_INET, SOCK_STREAM, 0);
	if (serverSock == -1) {
		perror("socket failed");
		exit(1);
	}

	// serverAddr - connect
	if (connect(serverSock, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == -1) {
		perror("connect failed");
		exit(1);
	}

	printf("\033[32m------------- Welcome!! -------------\n");
	printf("   |  function         |  command\n");
	printf("-------------------------------------\n");
	printf("1) |  send msg to idR  |  idR\\msg\n");
	printf("2) |  send msg to all  |  all\\msg\n");
	printf("3) |  ban idR          |  ban\\idR\n");
	printf("4) |  unban idR        |  unban\\idR\n");
	printf("5) |  state - busy     |  busy\\\n");
	printf("6) |  state - unbusy   |  unbusy\\\n");
	printf("7) |  user's state     |  state\\\n");
	printf("8) |  quit             |  \\quit\n");
	printf("-------------------------------------\033[0m\n");

	while (1) {
		FD_ZERO(&rfds);
		FD_SET(0, &rfds);
		maxfd = 0;
		FD_SET(serverSock, &rfds);
		if (serverSock > maxfd) maxfd = serverSock;
		tv.tv_sec = 1;
		tv.tv_usec = 0;
		retval = select(maxfd+1, &rfds, NULL, NULL, &tv);
		if (retval == -1) {
			printf("select error\n");
			break;
		}
		else if (retval == 0) continue;
		else {
			if (FD_ISSET(serverSock, &rfds)) {
				bzero(buffer, MAXBUF+1);
				len = recv(serverSock, buffer, MAXBUF, 0);
				if (len > 0) {
					str1 = strtok(buffer, "\\");
					str2 = strtok(NULL, "\\");
					if (!strcmp(str2, "Server")) printf("\033[33m%s >> %s\033[0m\n", str2, str1);
					else printf("%s >> %s\n", str2, str1);
				}
				else {
					if (len < 0) printf("recv error\n");
					else printf("quit\n");
					break;
				}
			}
			if (FD_ISSET(0, &rfds)) {
				bzero(buffer, MAXBUF+1);
				fgets(buffer, MAXBUF, stdin);
				if (!strncasecmp(buffer, "\\quit", 5)) {
					printf("self request to quit the chatting\n");
					break;
				}
				len = send(serverSock, buffer, strlen(buffer)-1, 0);
				if (len < 0) {
					printf("send error\n");
					break;
				}
			}
		} // end of selecting process
	} // end while
}
