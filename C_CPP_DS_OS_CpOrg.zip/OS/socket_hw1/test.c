/* struct test -- how to use struct */

#include <stdio.h>

int main(void)
{
	struct client {
		int id;
		char *msg;
	};

	struct client c1, c2, c3;

	c1.id = 1;
	c2.id = 2;
	c3.id = 3;

	c1.msg = "i'm client 1!";
	c2.msg = "i'm client 2!";
	c3.msg = "i'm client 3!";

	printf("%d -- %s\n", c1.id, c1.msg);
	printf("%d -- %s\n", c2.id, c2.msg);
	printf("%d -- %s\n", c3.id, c3.msg);
}
