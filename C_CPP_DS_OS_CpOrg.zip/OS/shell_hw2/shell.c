/* A Simple Linux Shell */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#define MAXSIZE 100

int main(int argc, char *argv[], char *envp[])
{
	char input[MAXSIZE], *split[10], *tSplit;
	int i;

	while (1) {
		for (i = 0; i < MAXSIZE; ++i) {
			input[i] = '\0';
		}
		printf("$ ");
		scanf("%s", input);
		if (!strcmp(input, "ls")) {
			if (fork() == 0) execve("/bin/ls", argv, envp);
			else wait(NULL);
		}
		else if(!strcmp(input, "pwd")) {
			if (fork() == 0) execve("/bin/pwd", argv, envp);
			else wait(NULL);
		}
	}
}
