/* test -- strtok */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
	char buf[512];
	printf("$ ");
	fgets(buf, 512, stdin);
	char *test = strtok(buf, " ");
	char *str[8];
	int i = 0, j;
	for (j = 0; j < 8; ++j) {
		str[j] = malloc(32);
	}

	while (test != NULL && i < 8) {
		printf("%s\n", test);
		strcpy(str[i++], test);
		printf("%d -- %s\n", i, str[i-1]);
		test = strtok(NULL, " ");
	}
}
