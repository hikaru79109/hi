/* A Simple Linux Shell */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#define MAXSIZE 512

int countArgs(char buf[MAXSIZE])
{
	char bufTemp[MAXSIZE];
	strcpy(bufTemp, buf);

	int num = 0;
	char *temp = strtok(bufTemp, " ");
	while (temp != NULL) {
		temp = strtok(NULL, " ");
		++num;
	}
	return num;
}

void parse(char buf[MAXSIZE], int num, char **args)
{
	char bufTemp[MAXSIZE];
	strcpy(bufTemp, buf);

	char *test = strtok(bufTemp, " ");
	int i = 0, j;

	for (j = 0; j < num; ++j) {
		args[j] = malloc(32);
	}

	while (test != NULL) {
		strcpy(args[i++], test);
		test = strtok(NULL, " ");
	}
}

void printCpuInfo()
{
	FILE *fp;
	char buf[4096];
	size_t bytes_read;
	char *match;
	float clock_speed;
	int cpu = 0;

	fp = fopen("/proc/cpuinfo", "r");
	bytes_read = fread(buf, 1, sizeof(buf), fp);
	fclose(fp);
	if (bytes_read == 0 || bytes_read == sizeof(buf)) clock_speed = 0;
	buf[bytes_read] = '\0';
	match = strstr(buf, "cpu MHz");
	if (match == NULL) clock_speed = 0;

	printf("PROCESSOR\tCPUMHZ\n");
	while (1) {
		sscanf(match, "cpu MHz : %f", &clock_speed);
		printf("%d\t\t%4.0f\n", cpu++, clock_speed);
		if ((match = strstr(match, "processor")) == NULL) break;
		match = strstr(match, "cpu MHz");
	}
}

void printPidOfExe(char *exe)
{
	FILE *fp;
	char exename[MAXSIZE] = "/proc/", pid[32];
	char buf[MAXSIZE];
	int i;

	for (i = 0; i < 10000; ++i) {
		bzero(pid, sizeof(pid));
		bzero(exename, sizeof(exename));
		strcat(exename, "/proc/");
		sprintf(pid, "%d", i);
		strcat(exename, pid);
		strcat(exename, "/exename");
		fp = fopen(exename, "r");
		if (fp) {
			bzero(buf, sizeof(buf));
			fread(buf, 1, sizeof(buf), fp);
			fclose(fp);
			if (!strcmp(buf, exe)) {
				printf("%d\n", i);
			}
		}
	}
}

int main()
{
	char buffer[MAXSIZE];
	char *path = "/bin/";

	while (1) {
		printf("$ ");
		gets(buffer);
		if (!strcmp(buffer, "exit")) exit(0);
		else if(!strcmp(buffer, "cpuinfo"))	printCpuInfo();
		else {
			if (fork() != 0) wait(NULL);
			else {
				int numOfArgs = countArgs(buffer);
				char *args[numOfArgs+1];
				parse(buffer, numOfArgs, args);
				args[numOfArgs] = NULL;
				char prog[MAXSIZE];
				char *envp[] = {"PATH=/bin", 0};
				strcpy(prog, path);
				strcat(prog, args[0]);
				//execv(prog, args);
				if (!strcmp(args[0], "pidofexe")) {
					printPidOfExe(args[1]);
					exit(0);
				}
				else if (strcmp(args[0], "echo") && strcmp(args[0], "pwd") && strcmp(args[0], "cat") && strcmp(args[0], "ls")) {
					printf("command not found\n");
					exit(0);
				}
				else {
					execve(prog, args, envp);
					printf("$$");
				}
			}
		}
	}
}
