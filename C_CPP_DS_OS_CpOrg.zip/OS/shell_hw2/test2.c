#include<unistd.h>
#include<stdio.h>
main()
{
	//char * argv[ ]={"ls","-al","/etc/passwd",(char *)0};
	char * argv[ ]={"cat","test2.c",NULL};
	char * envp[ ]={"PATH=/bin",0};
	int i;
	for (i = 0; i < 3; ++i) {
		printf("%s#", argv[i]);
	}
	//execve("/bin/cat",argv,envp);
}
