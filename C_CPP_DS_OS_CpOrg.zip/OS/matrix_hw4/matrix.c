/* calculate matrix C = A1B1 + A2B2 */
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

pthread_mutex_t mutex;
pthread_cond_t hold;

// C1 = A1B1; C2 = A2B2; C = C1 + C2
static int **A1, **A2, **B1, **B2;
static int **C1, **C2, **C;
static int signalP[3];
int m, n;

void createMatrix()
{
	int i;
	A1 = malloc(m * sizeof(int *));
	A2 = malloc(m * sizeof(int *));
	C1 = malloc(m * sizeof(int *));
	C2 = malloc(m * sizeof(int *));
	C = malloc(m * sizeof(int *));
	for (i = 0; i < m; ++i) {
		A1[i] = malloc(n * sizeof(int));
		A2[i] = malloc(n * sizeof(int));
		C1[i] = malloc(m * sizeof(int));
		C2[i] = malloc(m * sizeof(int));
		C[i] = malloc(m * sizeof(int));
	}

	B1 = malloc(n * sizeof(int *));
	B2 = malloc(n * sizeof(int *));
	for (i = 0; i < n; ++i) {
		B1[i] = malloc(m * sizeof(int));
		B2[i] = malloc(m * sizeof(int));
	}
}

void setMatrix()
{
	int i, j;

	// A1
	for (i = 0; i < m; ++i) {
		for (j = 0; j < n; ++j) {
			scanf("%d", &A1[i][j]);
		}
	}

	// B1
	for (i = 0; i < n; ++i) {
		for (j = 0; j < m; ++j) {
			scanf("%d", &A1[i][j]);
		}
	}

	// A2
	for (i = 0; i < m; ++i) {
		for (j = 0; j < n; ++j) {
			scanf("%d", &A1[i][j]);
		}
	}

	// B2
	for (i = 0; i < n; ++i) {
		for (j = 0; j < m; ++j) {
			scanf("%d", &A1[i][j]);
		}
	}
}

void initMatrix()
{
	int i, j;
	for (i = 0; i < m; ++i) {
		for (j = 0; j < m; ++j) {
			C[i][j] = 0;
			C1[i][j] = 0;
			C2[i][j] = 0;
		}
	}
}

void *calculateMatrix(void *pth)
{
	int i = 0, j = 0, k = 0;
	if (!strcmp(pth, "P1")) {
		// wait for signal P0
		pthread_mutex_lock(&mutex);
		while (!signalP[0]) {
			pthread_cond_wait(&hold, &mutex);
			printf("P1 signal received\n");
		}

		// calculate
		for (i = 0; i < m; ++i) {
			for (j = 0; j < m; ++j) {
				for (k = 0; k < n; ++k) {
					C1[i][j] = A1[i][k] * B1[k][j];
					printf("%d ", C1[i][j]);
				}
			}
		}

		// send signal to P0
		signalP[1] = 1;
		pthread_cond_signal(&hold);
		pthread_mutex_unlock(&mutex);
		printf("C1 finished\n");
	}

	else {
		pthread_mutex_lock(&mutex);
		while (!signalP[0]) {
			pthread_cond_wait(&hold, &mutex);
			printf("P2 signal received\n");
		}

		for (i = 0; i < m; ++i) {
			for (j = 0; j < m; ++j) {
				for (k = 0; k < n; ++k) {
					C2[i][j] = A2[i][k] * B2[k][j];
					printf("%d ", C2[i][j]);
				}
			}
		}

		signalP[2] = 1;
		pthread_cond_signal(&hold);
		pthread_mutex_unlock(&mutex);
		printf("C2 finished\n");
	}
	pthread_exit(NULL);
}

int main()
{
	int i = 0 , j = 0;

	// initialize signal to 0
	for (i = 0; i < 3; ++i) {
		signalP[i] = 0;
	}
	pthread_mutex_init(&mutex, NULL);
	pthread_cond_init(&hold, NULL);

	// thread's id
	pthread_t id_pth, id_pth2;

	// create thread
	pthread_create(&id_pth, NULL, calculateMatrix, "P1");
	pthread_create(&id_pth2, NULL, calculateMatrix, "P2");

	// 2 m*n matrix A1, A2; 2 n*m matrix B1, B2
	// 3 m*m matrix C, C1, C2
	scanf("%d", &m);
	scanf("%d", &n);
	createMatrix(m, n);
	initMatrix(m, n);
	setMatrix(m, n);
	printf("set finished\n");

	// send signal to P1 and P2
	pthread_mutex_lock(&mutex);
	signalP[0] = 1;
	pthread_cond_broadcast(&hold);
	pthread_mutex_unlock(&mutex);

	// wait for the thread (signal P1 and signal P2)
	pthread_mutex_lock(&mutex);
	printf("calculating...\n");
	while (!signalP[1] || !signalP[2]) {
		pthread_cond_wait(&hold, &mutex);
		printf("P0 signal receiced\n");
	}

	//pthread_join(id_pth, NULL);
	//pthread_join(id_pth2, NULL);

	// C = C1 + C2
	for (i = 0; i < m; ++i) {
		for (j = 0; j < m; ++j) {
			C[i][j] = C1[i][j] + C2[i][j];
			printf("%d ", C[i][j]);
		}
		printf("\n");
	}
	pthread_mutex_unlock(&mutex);
}
