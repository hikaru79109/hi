/* multithread */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#define MAXSIZE 65536 // 2^16

static int count = 0; // # of matched str
char *fileName, *searchStr, *startStr;
char *fileText, *text[2];
int fsize;

void fileProcess(char *arg[])
{
	fileName = arg[1];
	searchStr = arg[2];
	startStr = malloc(sizeof(searchStr)-4);
	int i = 0, j = 0, half = 0;
	for (i = 1; i < strlen(searchStr); ++i) {
		startStr[i-1] = searchStr[i];
	}

	// open file
	FILE *fp;
	if ((fp = fopen(fileName, "r")) == NULL) {
		perror("file open error!");
		exit(0);
	}

	fileText = malloc(MAXSIZE);
	fsize = fread(fileText, 1, MAXSIZE, fp);
	//fileText[fsize] = '\0'; // set ending char

	half = fsize / 2;
	while (fileText[++half] != '\n');
	text[0] = malloc(half);
	text[1] = malloc(fsize - half);

	for (i = 0; i < half; ++i) {
		text[0][i] = fileText[i];
	}
	text[0][half] = '\0';

	for (i = half + 1, j = 0; i < fsize; ++i, ++j) {
		text[1][j] = fileText[i];
	}
	text[1][j] = '\0';

	// close file
	fclose(fp);
}

void *search(void *pth)
{
	int th;
	if (!strcmp(pth, "1")) th = 0;
	else th = 1;
	int c = 0;
	while (text[th] != NULL) {
		if ((text[th] = strstr(text[th], searchStr)) != NULL) {
			text[th] = strstr(text[th], startStr);
			++count;
			++c;
		}
		else break;
	}
	printf("Total in thread %s: %d\n", pth, c);
	return 0;
}

int main(int argc, char *argv[])
{
	// expect if enter the filename and searching string
	if (argc < 3) {
		perror("Please enter the filename and searching string!");
		exit(0);
	}

	// file processing
	fileProcess(argv);

	// thread's id
	pthread_t id_pth, id_pth2;

	// create thread
	pthread_create(&id_pth, NULL, search, "1");
	pthread_create(&id_pth2, NULL, search, "2");

	// wait for the thread
	pthread_join(id_pth, NULL);
	pthread_join(id_pth2, NULL);

	printf("Total: %d\n", count);
}
