/* multithread */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#define MAXSIZE 1048576 // 2^20

static int count = 0; // # of matched str
char *fileName, *searchStr, *startStr;
static char fileText[MAXSIZE];
int fsize;
//pthread_mutex_t mutex;
//struct timespec delay;

void fileProcess(char *arg[])
{
	fileName = arg[1];
	searchStr = arg[2];
	startStr = malloc(sizeof(searchStr)-4);
	int i;
	for (i = 1; i < strlen(searchStr); ++i) {
		startStr[i-1] = searchStr[i];
	}

	// open file
	FILE *fp;
	if ((fp = fopen(fileName, "r")) == NULL) {
		perror("file open error!");
		exit(0);
	}

	fsize = fread(fileText, 1, MAXSIZE, fp);
	fileText[fsize] = '\0'; // set ending char

	// close file
	fclose(fp);
}

void *search(void *pth)
{
	char *temp;
	int c = 0;
	while (fileText != NULL) {
		if ((temp = strstr(fileText, searchStr)) != NULL) {
			//pthread_mutex_lock(&mutex);
			//if (pthread_mutex_trylock(&count) != 0) continue;
			//pthread_mutex_lock(fileText);
			//pthread_mutex_lock(&count);
			temp = strstr(temp, startStr);
			strcpy(fileText, temp);
			++count;
			++c;
			//pthread_mutex_unlock(&count);
			//pthread_mutex_unlock(fileText);
			//pthread_mutex_unlock(&mutex);
			//pthread_delay_np(&delay);
		}
		else break;
		//printf("\"%s\"/%d\n", pth, c);
		//printf("\"%s\"/%s\n", pth, fileText);
	}
	printf("Total in thread %s: %d\n", pth, c);
	return 0;
}

int main(int argc, char *argv[])
{
	// expect if enter the filename and searching string
	if (argc < 3) {
		perror("Please enter the filename and searching string!");
		exit(0);
	}

	// file processing
	fileProcess(argv);

	// thread's id
	pthread_t id_pth, id_pth2;

	//delay.tv_sec = 2;
	//pthread_mutex_init(&mutex, NULL);

	// create thread
	pthread_create(&id_pth, NULL, search, "1");
	pthread_create(&id_pth2, NULL, search, "2");

	// wait for the thread
	pthread_join(id_pth, NULL);
	pthread_join(id_pth2, NULL);

	printf("Total: %d\n", count);
}
