
#include "io430.h"

extern  int matrix_A;
extern  int matrix_B;
extern  int *matrix_mul(int[3][3], int[3][3]);

int matrix_ans[3][3];

int *matrixMul(int A[3][3], int B[3][3])
{
  int i, j;
  for (i = 0; i < 3; ++i) {
    for (j = 0; j < 3; ++j) {
      matrix_ans[i][j] = A[i][0]*B[0][j] + A[i][1]*B[1][j] + A[i][2]*B[2][j];
    }
  }
  return &matrix_ans[0][0];
}

int main( void )
{
  // Stop watchdog timer to prevent time out reset
  WDTCTL = WDTPW + WDTHOLD;
  int *addrA, *addrB;
  addrA = &matrix_A;
  addrB = &matrix_B;
  int i, j;
  int matrixA[3][3], matrixB[3][3];
  for (i = 0; i < 3; ++i) {
    for (j = 0; j < 3; ++j) {
      matrixA[i][j] = *addrA;
      matrixB[i][j] = *addrB;
      addrA += 1;
      addrB += 1;
    }
  }

  int *c_call_c_ans_addr; // R10
  int *c_call_asm_ans_addr; // R15
  // return value(address) is pass by R12 and save in R10
  c_call_c_ans_addr = matrixMul(matrixA, matrixB); 
  // return value(address) is pass by R12 and save in R15
  c_call_asm_ans_addr = matrix_mul(matrixA, matrixB);
  
  return 0;
}
