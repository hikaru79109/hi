#include "msp430.h"                     ; #define controlled include file

BCD_TO_HEX MACRO BCD_NUM
LOCAL outloop inloop calculate
  PUSH  R4
  PUSH  R5
  PUSH  R6
  PUSH  R7
  MOV.W BCD_NUM, R4                     ; input value
  MOV.W #1, R5                          ; R5 = 1, 10, 100, 1000
  MOV.W #16, R7                         ; for outloop
  CLR.W R12                             ; result
  CLR.W R14                             ; temp value
    
outloop:                                ; for R7 = 16 to 0
  MOV.W #4, R6                          ; for inloop
  CLR.W R13                             ; 4-bit value
  CMP.W #0, R7
  JZ    calculate
    
; R4 is the input value
; R13 is the value of right 4 bit of R4
inloop:                                 ; for R6 = 4 to 0
  RLA   R13                             ; R13 *= 2
  RLC   R4                              ; move lsb to C
  ADC.W R13                             ; R13 += C
  DEC.W R6                              ; R6--
  DEC.W R7                              ; R7--
  CMP.W #0, R6
  JNZ   inloop
  PUSH  R13
  JMP   outloop
    
calculate:
  POP   R13
  ; R14 = R13 * R5
  MOV.W R13, &MPY
  MOV.W R5, &OP2
  MOV.W RESLO, R14
  ADD.W R14, R12
    
  ; R5 *= 10
  MOV.W R5, &MPY
  MOV.W #10, &OP2
  MOV.W RESLO, R5
    
  DEC.W R6                              ; R6--
  CMP.W #0, R6
  JNZ   calculate
    
  POP R7
  POP R6
  POP R5
  POP R4
  ENDM