#include "msp430.h"                     ; #define controlled include file

HEX_TO_BCD MACRO HEX_NUM
LOCAL

  PUSH  R4
  PUSH  R5
  PUSH  R6
  PUSH  R7
  MOV.W HEX_NUM, R4                     ; input value
  CLR.W R13                             ; result
  MOV.W #16, R15
loop:  
  RLA.W R4
  DADD.W  R13, R13
  DEC.W R15
  JNZ   loop
    
  ENDM