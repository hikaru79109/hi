#include "msp430.h"                     ; #define controlled include file

CHECK_BCD MACRO NUM
LOCAL for valid exit invalid
        PUSH    R4
        PUSH    R5
        PUSH    R6
        MOV.W   NUM, R4
        MOV.W   #0x0004, R5             ; except 4 times
        MOV.W   #0xA000, R6
for:
        CLR.W   SR
        CMP.W   R4, R6
        JZ      invalid                 ; R4 = 0xA000
        JC      valid                   ; R4 < 0xA000
        JMP     invalid                 ; R4 > 0xA000
valid:
        ;CMP.W   R4, R6
        ;JZ      invalid
        RLA     R4
        RLA     R4
        RLA     R4
        RLA     R4
        CMP     R5, R6                  ; C = 1
        DEC.W   R5
        CMP     #0, R5
        JZ      exit
        JMP     for
invalid:      
        CMP     R6, R5                  ; C = 0          
exit:      
          
        POP     R6
        POP     R5
        POP     R4
          
        ENDM